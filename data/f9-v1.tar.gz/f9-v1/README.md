# armbench F9 evaluation dataset (core)

Pre-registered evaluation `f9-v1` of https://github.com/aiambo08/energy-aware-arm-agent
(protocol sha256 `845c11742d269d36cfcdde5610be15c6933829079fa7b6f3c10838075cb502b5`): agents A, B, B+S, C, C+S x tasks pick_place@1, stack2@1,
sort3@1, place_obstacle@1 x locked seeds 100-119 in Gazebo Harmonic, LLM
`Qwen/Qwen3-235B-A22B-Instruct-2507` (Nebius Token Factory, temperature 0).

- `<run>/run.json`: run metadata (agent, git sha, LLM profile, protocol hash).
- `<run>/episodes.jsonl`: one EpisodeRecord (schema v1) per episode: verdict, failure stage,
  Wh for energy variants A/B x eta 0.6/0.7/0.8, agent trace (tokens, cost, calls).
- `<run>/programs/`: the program the agent wrote per episode and its sandbox trace.
- `<run>/llm/cache/`: content-addressed LLM responses; `armbench run --provider replay` serves
  them without a network call.
- `MANIFEST.json`: sha256 of every file in this bundle.

Run directories `f9_BSS` and `f9_CSS` hold agents B+S and C+S (the agent id is in `run.json`).
Regenerate the analysis: `uv run armbench analyze f9-v1/f9_A f9-v1/f9_B f9-v1/f9_BSS
f9-v1/f9_C f9-v1/f9_CSS --out f9_eval.json` (report sha256 `87390f0bfe0be03eb58b137831987aebb81190498f8ba26a0d35d16512559028`).

License: CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/). Cite as in CITATION.cff of
the repository.
