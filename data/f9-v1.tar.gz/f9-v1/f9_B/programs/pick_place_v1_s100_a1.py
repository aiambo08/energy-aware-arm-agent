def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If green cube not found or not fully visible, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation angle
if target is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green")

# If we found the green cube, proceed to move it
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.553, -0.191, pick_pose.z, target.yaw_rad)
    
    # Approach from above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly
    robot.move_to(pick_pose, 0.5)
    # Grasp
    robot.grasp()
    # Lift
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to destination
    robot.move_to(place_pose.above(0.10))
    # Descend slowly to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
