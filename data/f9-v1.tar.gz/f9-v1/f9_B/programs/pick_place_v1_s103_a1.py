def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose
if yellow is None or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))  # Better view for y=0.191
    detections = robot.detect("yellow")
    yellow = find_cube(detections, "yellow") or yellow  # Fallback to previous if still not found

# If we have a detection, proceed
if yellow is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not detected")

# Define pick and place poses
pick_pose = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
place_pose = Pose(-0.368, 0.191, pick_pose.z, yellow.yaw_rad)

# Approach from above, grasp, lift
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Move to above target location
robot.move_to(place_pose.above(0.10))

# Place the cube
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_pose.above(0.10))
