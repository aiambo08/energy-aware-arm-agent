def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("blue")
blue_cube = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue") or blue_cube

# If still not found, try another observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue") or blue_cube

# If we have a detection, proceed with move
if blue_cube is not None:
    pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
    place_pose = Pose(-0.495, 0.173, pick_pose.z, blue_cube.yaw_rad)
    
    # Approach from above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly
    robot.move_to(pick_pose, 0.5)
    # Grasp
    robot.grasp()
    # Lift
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to target location
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
