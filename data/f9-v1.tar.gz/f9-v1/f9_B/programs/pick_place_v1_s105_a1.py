def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose
if yellow is None or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("yellow")
    yellow = find_cube(detections, "yellow") or yellow
    # If still not found, try another observation pose
    if yellow is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect("yellow")
        yellow = find_cube(detections, "yellow")

# If we found the yellow cube, move it
if yellow is not None:
    pick_pose = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
    place_pose = Pose(-0.528, -0.166, pick_pose.z)
    
    # Approach from above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly
    robot.move_to(pick_pose, 0.5)
    # Grasp
    robot.grasp()
    # Lift
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to target location
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
