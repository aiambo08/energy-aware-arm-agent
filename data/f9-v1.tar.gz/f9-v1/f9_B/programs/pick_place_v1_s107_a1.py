def find_cube(detections, color):
    for det in detections:
        if det.color == color:
            return det
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or not complete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red")
    # If still not found, try another observation angle
    if target is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect()
        target = find_cube(detections, "red")

# If we found the red cube, proceed with pick and place
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.418, -0.166, pick_pose.z)
    
    # Approach from 10 cm above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly to pick pose
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    # Lift with slow speed
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to above place position
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table (5 mm above resting height)
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
