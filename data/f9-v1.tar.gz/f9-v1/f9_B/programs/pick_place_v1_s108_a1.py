def find_cube(detections, color):
    for det in detections:
        if det.color == color:
            return det
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "blue")

# If blue cube not found or not fully visible, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "blue")
    
    # If still not found, check other observation poses
    if target is None:
        for obs_pose in [Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]:
            robot.move_to(obs_pose)
            detections = robot.detect()
            target = find_cube(detections, "blue")
            if target is not None:
                break

# If we found the blue cube, move it
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.382, 0.143, pick_pose.z, pick_pose.yaw)
    
    # Approach from above
    approach_height = 0.10
    robot.move_to(pick_pose.above(approach_height))
    
    # Descend and grasp
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    
    # Lift with slow speed
    robot.move_to(pick_pose.above(approach_height), 0.5)
    
    # Move to place position
    robot.move_to(place_pose.above(approach_height))
    
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    
    # Release and lift
    robot.release()
    robot.move_to(place_pose.above(approach_height))
