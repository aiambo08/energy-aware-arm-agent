def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or not fully visible, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, try another observation angle
if target is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If we have a detection, proceed with pick and place
if target is None:
    raise PrimitiveError("No red cube detected", "NOT_FOUND")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.389, 0.061, pick_pose.z, pick_pose.yaw)

# Pick the red cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()

# Lift the cube
robot.move_to(pick_pose.above(0.10), 0.5)

# Move to above the target location
robot.move_to(place_pose.above(0.10))

# Place the cube
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift the gripper
robot.move_to(place_pose.above(0.10))
