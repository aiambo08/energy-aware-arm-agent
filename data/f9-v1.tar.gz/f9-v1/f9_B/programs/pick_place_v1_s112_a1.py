def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose to get better view
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If still not found, try another observation angle
if target is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If we have a detection, proceed with pick and place
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube centre height when resting on table
    place_pose = Pose(-0.364, -0.062, place_z, target.yaw_rad)
    
    # Approach from 10 cm above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly to pick pose
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    # Lift with slow speed
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to above place position
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    # Lift back to safe height
    robot.move_to(place_pose.above(0.10))
