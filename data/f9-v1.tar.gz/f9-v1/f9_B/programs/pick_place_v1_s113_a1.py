def find_cube(detections, color):
    for det in detections:
        if det.color == color:
            return det
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or detection is incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, try another observation angle
if target is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If we have a detection, proceed with pick and place
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.510, 0.172, pick_pose.z)
    
    # Approach from above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly
    robot.move_to(pick_pose, 0.5)
    # Grasp the cube
    robot.grasp()
    # Lift up
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to target location
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release the cube
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
