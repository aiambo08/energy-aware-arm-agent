def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("blue")
blue = find_cube(detections, "blue")

# If blue cube not found or not fully visible, move to observation pose
if blue is None or not blue.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("blue")
    blue = find_cube(detections, "blue") or blue  # Use previous if still not found

# If we don't have a blue cube detection, we cannot proceed
if blue is None:
    robot.reset()
else:
    # Define pick and place poses
    pick_pose = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
    place_pose = Pose(-0.518, 0.187, blue.position[2], blue.yaw_rad)
    
    # Approach from 10 cm above
    approach_height = 0.10
    release_height = 0.005
    
    # Move to pick position
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(approach_height), 0.5)
    
    # Move to place position
    robot.move_to(place_pose.above(approach_height))
    robot.move_to(place_pose.above(release_height), 0.5)
    robot.release()
    robot.move_to(place_pose.above(approach_height))
