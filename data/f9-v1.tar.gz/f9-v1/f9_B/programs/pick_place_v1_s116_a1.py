def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("blue")
blue_cube = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue") or blue_cube
    # If still not found, try another observation angle
    if blue_cube is None:
        robot.move_to(Pose(-0.30, 0.25, 0.15))
        detections = robot.detect("blue")
        blue_cube = find_cube(detections, "blue")

# If we found the blue cube, proceed to move it
if blue_cube is not None:
    # Define pick and place poses
    pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
    place_pose = Pose(-0.558, 0.131, pick_pose.z, pick_pose.yaw_rad)
    
    # Approach from above, grasp, lift
    robot.move_to(pick_pose.above(0.10))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)
    
    # Move to target location and place
    robot.move_to(place_pose.above(0.10))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(0.10))
