def find_cube(detections, color):
    for det in detections:
        if det.color == color:
            return det
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If green cube not found or not complete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If we have a detection, proceed with pick and place
if target is None:
    raise PrimitiveError("No green cube detected")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.477, -0.003, pick_pose.z, target.yaw_rad)

# Pick the green cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place the green cube at target location
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10))
