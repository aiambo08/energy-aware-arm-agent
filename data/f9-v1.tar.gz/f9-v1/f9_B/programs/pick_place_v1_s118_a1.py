def find_cube(detections, color):
    for det in detections:
        if det.color == color:
            return det
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or not complete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red")
    # If still not found, try another observation angle
    if target is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect()
        target = find_cube(detections, "red")

# If we found the red cube, proceed with pick and place
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube centre height when resting on table
    place_pose = Pose(-0.624, -0.181, place_z, target.yaw_rad)
    
    # Approach from above
    approach_height = 0.10
    robot.move_to(pick_pose.above(approach_height))
    
    # Descend and grasp
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    
    # Lift with slow speed
    robot.move_to(pick_pose.above(approach_height), 0.5)
    
    # Move to place position
    robot.move_to(place_pose.above(approach_height))
    
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    
    # Release and lift
    robot.release()
    robot.move_to(place_pose.above(approach_height))
