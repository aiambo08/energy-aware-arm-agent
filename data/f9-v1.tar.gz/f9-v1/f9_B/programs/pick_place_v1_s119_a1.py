def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("blue")
blue_cube = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue") or find_cube(robot.detect(), "blue")

# If still not found, try another observation pose
if blue_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue")

# If still not found, try the last observation pose
if blue_cube is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect("blue")
    blue_cube = find_cube(detections, "blue")

# If we found the blue cube, move it to the target position
if blue_cube is not None:
    pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
    target_z = 0.0225  # Cube resting on table (half of 4.5 cm height)
    place_pose = Pose(-0.579, 0.108, target_z, blue_cube.yaw_rad)
    
    # Approach from 10 cm above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly to grasp pose
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    # Lift slowly with cube
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to above target position
    robot.move_to(place_pose.above(0.10))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    # Lift back up
    robot.move_to(place_pose.above(0.10))
