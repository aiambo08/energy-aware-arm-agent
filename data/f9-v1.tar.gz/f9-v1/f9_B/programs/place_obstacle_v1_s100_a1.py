def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect("blue")
blue = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue is None or not blue.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect("blue")
    blue = find_cube(detections, "blue") or blue  # Use previous if still not found

# If still not found, try another observation pose
if blue is None or not blue.complete:
    obs_pose2 = Pose(-0.30, 0.0, 0.15)
    robot.move_to(obs_pose2)
    detections = robot.detect("blue")
    blue = find_cube(detections, "blue") or blue

# If we don't have a blue cube, we cannot proceed
if blue is None:
    robot.reset()
    raise PrimitiveError("code": "NO_BLUE", "message": "Blue cube not found")

# Define pick and place poses
pick = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
target_z = 0.0225  # Resting height of cube on table
place = Pose(-0.517, 0.196, target_z, blue.yaw_rad)

# Approach from above, avoiding wall
approach_height = 0.10
safe_retract_height = 0.10

# Move to pick
robot.move_to(pick.above(approach_height))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(safe_retract_height), 0.5)

# Move to place (go high enough to clear wall)
robot.move_to(place.above(0.12))  # Over wall (10 cm high)
robot.move_to(place.above(0.005), 0.5)  # Just above table
robot.release()
robot.move_to(place.above(safe_retract_height))
