def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue_cube = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube

# If still not found, try another observation pose
if blue_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue")

# If we don't have the blue cube, we cannot complete the task
if blue_cube is None:
    robot.reset()
else:
    # Define pick and place poses
    pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
    place_pose = Pose(-0.595, -0.111, pick_pose.z, pick_pose.yaw_rad)
    
    # Approach from above, avoiding the wall
    approach_height = 0.10
    lift_height = 0.10
    
    # Move above the cube
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(lift_height), 0.5)
    
    # Move above the target, avoiding the wall by going higher
    robot.move_to(place_pose.above(lift_height))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(lift_height))
