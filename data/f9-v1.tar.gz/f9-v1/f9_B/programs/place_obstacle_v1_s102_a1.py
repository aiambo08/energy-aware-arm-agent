def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose)
            detections = robot.detect()
            target = find_cube(detections, "green")
            if target is not None and target.complete:
                break
        except (OutOfReach, Singularity, Collision):
            continue

# If still not found, use the best available
if target is None:
    target = find_cube(robot.detect("green"), "green")
    if target is None:
        robot.reset()
        raise PrimitiveError("code": "NO_TARGET", "message": "Green cube not found")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.640, -0.073, pick_pose.z, target.yaw_rad)

# Plan approach to avoid wall: go via a higher intermediate point
via_z = 0.20  # High enough to clear the 10 cm wall with clearance

try:
    # Move above pick point at safe height
    robot.move_to(pick_pose.above(via_z))
    # Descend to pick
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    # Lift with cube
    robot.move_to(pick_pose.above(via_z), 0.5)
    # Move above place point
    robot.move_to(place_pose.above(via_z))
    # Descend to place
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    # Lift slightly after release
    robot.move_to(place_pose.above(via_z))
except (OutOfReach, Singularity, Collision, Timeout) as e:
    robot.reset()
    raise e
