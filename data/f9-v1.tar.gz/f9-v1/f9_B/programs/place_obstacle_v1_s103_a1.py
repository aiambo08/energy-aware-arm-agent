def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If we don't have the red cube, we cannot proceed
if target is None:
    robot.reset()
    raise PrimitiveError("No red cube detected")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.548, 0.109, pick_pose.z, pick_pose.yaw)

# Approach from above, avoiding the wall by going higher
safe_height = 0.12  # Above the 10 cm wall
try:
    robot.move_to(pick_pose.above(safe_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(safe_height), 0.5)
    robot.move_to(place_pose.above(safe_height))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(safe_height))
except (OutOfReach, Singularity, Collision, Timeout) as e:
    robot.reset()
    raise e
