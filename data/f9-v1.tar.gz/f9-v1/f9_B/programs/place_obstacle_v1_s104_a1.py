def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If not found or incomplete, move to observation pose at near edge
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try last observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If we don't have the green cube, we cannot complete
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube resting on table
    place = Pose(-0.359, 0.177, place_z, target.yaw_rad)

    # Plan path to avoid wall: go higher
    approach_height = 0.20

    # Move to pick position from above
    robot.move_to(pick.above(approach_height))
    robot.move_to(pick.above(0.02), 0.5)
    robot.grasp()
    robot.move_to(pick.above(approach_height), 0.5)

    # Move to place position from above
    robot.move_to(place.above(approach_height))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(approach_height))
