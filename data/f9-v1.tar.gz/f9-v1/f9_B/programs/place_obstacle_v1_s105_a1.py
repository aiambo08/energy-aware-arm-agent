def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose
if yellow is None or not yellow.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose)
            detections = robot.detect("yellow")
            yellow = find_cube(detections, "yellow")
            if yellow is not None and yellow.complete:
                break
        except:
            continue

# If still not found, use any yellow detection
if yellow is None:
    detections = robot.detect()
    yellow = find_cube(detections, "yellow")

# Define pick and place poses
pick_pose = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
place_pose = Pose(-0.566, 0.142, yellow.position[2], yellow.yaw_rad)

# Plan path to avoid wall: go higher (0.20 m) to clear the 10 cm wall
safe_height = 0.20

# Move to pick position via safe height
robot.move_to(pick_pose.above(safe_height))
robot.move_to(pick_pose.above(0.05), 0.5)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(safe_height), 0.5)

# Move to place position via safe height
robot.move_to(place_pose.above(safe_height))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(safe_height))
