def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("red")
target = find_cube(detections, "red")

# If not found or incomplete, move to observation pose to get better view
if target is None or not target.complete:
    try:
        robot.move_to(Pose(-0.30, 0.25, 0.15), 0.8)
    except (OutOfReach, Singularity, Collision):
        pass  # Should not happen for observation pose
    detections = robot.detect("red")
    target = find_cube(detections, "red") or target

# If still not found, try another observation pose
if target is None:
    try:
        robot.move_to(Pose(-0.30, -0.25, 0.15), 0.8)
    except (OutOfReach, Singularity, Collision):
        pass
    detections = robot.detect("red")
    target = find_cube(detections, "red") or target

# If no red cube found, we cannot proceed
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.525, 0.181, pick_pose.z, target.yaw_rad)
    
    # Plan path to avoid wall: go higher if necessary
    # Wall is at x=-0.591, y=0.008, so we must go around or over
    # Since wall is 10 cm high, we must lift above z=0.10 to clear
    lift_height = 0.12  # 12 cm to clear 10 cm wall with margin
    
    # Move above pick position at safe height
    approach_pick = pick_pose.above(lift_height)
    try:
        robot.move_to(approach_pick, 0.7)
    except (OutOfReach, Singularity, Collision):
        approach_pick = Pose(pick_pose.x, pick_pose.y, 0.12, pick_pose.yaw)
        robot.move_to(approach_pick, 0.7)
    
    # Descend to pick
    try:
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
    except NoObjectGrasped:
        # If grasp fails, try slight reposition
        offset_pick = Pose(pick_pose.x, pick_pose.y, pick_pose.z + 0.005, pick_pose.yaw)
        robot.move_to(offset_pick, 0.3)
        robot.move_to(pick_pose, 0.3)
        robot.grasp()
    
    # Lift with cube
    robot.move_to(approach_pick, 0.5)
    
    # Move above place position at safe height
    approach_place = place_pose.above(lift_height)
    try:
        robot.move_to(approach_place, 0.7)
    except (OutOfReach, Singularity, Collision):
        approach_place = Pose(place_pose.x, place_pose.y, 0.12, place_pose.yaw)
        robot.move_to(approach_place, 0.7)
    
    # Descend to place
    place_z = 0.0225  # Cube centre when resting on table
    final_place = Pose(place_pose.x, place_pose.y, place_z, place_pose.yaw)
    robot.move_to(final_place.above(0.005), 0.5)
    robot.release()
    
    # Lift slightly after release
    robot.move_to(final_place.above(0.05), 0.5)
