def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose to get better view
if yellow is None or not yellow.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose)
            detections = robot.detect("yellow")
            yellow = find_cube(detections, "yellow")
            if yellow is not None:
                break
        except (OutOfReach, Singularity, Collision):
            continue

# If still not found, use last known or estimated position
if yellow is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not detected")

# Define pick and place poses
pick_pose = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
target_x = -0.358
target_y = 0.195
place_z = 0.0225  # Cube resting on table
place_pose = Pose(target_x, target_y, place_z, yellow.yaw_rad)

# Plan path to avoid wall: use higher lift and intermediate waypoints if needed
lift_height = 0.15
approach_height = 0.05

# Move above pick position
robot.move_to(pick_pose.above(lift_height))
# Descend to pick
robot.move_to(pick_pose, 0.5)
# Grasp
robot.grasp()
# Lift with cube
robot.move_to(pick_pose.above(lift_height), 0.5)

# Move above place position via high arc to avoid wall
robot.move_to(place_pose.above(lift_height))
# Descend slightly to approach
robot.move_to(place_pose.above(approach_height))
# Final descent
robot.move_to(place_pose.above(0.005), 0.5)
# Release
robot.release()
# Lift slightly after release
robot.move_to(place_pose.above(0.05))
