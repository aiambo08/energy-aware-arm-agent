def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try last observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If we don't have the green cube, we cannot complete
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place = Pose(-0.394, 0.076, pick.z)
    
    # Plan path over the wall: go high enough (above 0.10 m) to clear the 0.10 m wall
    # and avoid swinging near the wall's location
    safe_height = 0.12
    
    # Move to safe height above pick
    robot.move_to(pick.above(safe_height))
    
    # Move horizontally above safe height to avoid wall
    robot.move_to(place.above(safe_height))
    
    # Descend to place
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    
    # Lift up
    robot.move_to(place.above(safe_height))
