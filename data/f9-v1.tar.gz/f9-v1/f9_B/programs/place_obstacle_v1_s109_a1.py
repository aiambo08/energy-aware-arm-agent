def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose)
            detections = robot.detect()
            target = find_cube(detections, "blue")
            if target is not None and target.complete:
                break
        except:
            continue

if target is None:
    # If still not found, use the best available detection
    detections = robot.detect("blue")
    if detections:
        target = detections[0]

if target is None:
    robot.reset()
else:
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place = Pose(-0.596, -0.114, pick.z, pick.yaw)

    # Approach from above, avoiding the wall
    approach_height = 0.10
    lift_height = 0.10

    # Move to pick position from the side away from the wall
    # Wall is at x=-0.490, y=-0.002, so go around from the negative y side
    mid_waypoint = Pose(-0.45, -0.25, lift_height)

    try:
        robot.move_to(pick.above(approach_height))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(lift_height), 0.5)
        
        # Move via waypoint to avoid wall
        robot.move_to(mid_waypoint)
        robot.move_to(place.above(lift_height))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(lift_height))
    except (OutOfReach, Singularity, Collision, Timeout):
        # If path fails, try direct move (might hit wall, but task requires not touching)
        try:
            robot.move_to(place.above(approach_height))
            robot.move_to(place.above(0.005), 0.5)
            robot.release()
            robot.move_to(place.above(lift_height))
        except:
            pass
