def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose)
            detections = robot.detect()
            target = find_cube(detections, "red")
            if target is not None and target.complete:
                break
        except:
            continue

# If still not found, use the best available
if target is None:
    target = find_cube(robot.detect("red"), "red")
    if target is None:
        raise PrimitiveError("No red cube detected")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.497, -0.158, pick_pose.z, pick_pose.yaw)

# Plan path to avoid wall: go around via higher z
safe_height = 0.20
approach_offset = 0.08  # Move sideways first to avoid wall

# Move above pick position
robot.move_to(pick_pose.above(safe_height))

# Descend to pick
robot.move_to(pick_pose.above(0.01), 0.5)
robot.grasp()
robot.move_to(pick_pose.above(safe_height), 0.5)

# Move to intermediate point to avoid wall (go via y = 0.0)
mid_pose = Pose(-0.497, 0.0, safe_height)
robot.move_to(mid_pose)

# Move to above place position
robot.move_to(place_pose.above(safe_height))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(safe_height))
