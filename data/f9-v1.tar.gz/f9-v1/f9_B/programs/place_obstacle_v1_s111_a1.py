def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If not found or incomplete, move to observation pose to get better view
if target is None or not target.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose, 0.7)
            detections = robot.detect()
            target = find_cube(detections, "red")
            if target is not None and target.complete:
                break
        except (OutOfReach, Singularity, Collision, Timeout):
            continue

if target is None:
    # If still not found, use the best available detection
    detections_all = robot.detect()
    target = find_cube(detections_all, "red")
    if target is None:
        robot.reset()
        raise PrimitiveError("code": "NO_TARGET", "message": "Red cube not found")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.376, 0.126, pick_pose.z, target.yaw_rad)

# Plan path to avoid wall: go north first, then east, then down
via_pose = Pose(-0.30, 0.126, 0.20)  # High north of wall, same y as goal
approach_pose = Pose(-0.376, 0.126, 0.10)  # Above final position

# Move to pick position via safe path
robot.move_to(pick_pose.above(0.10), 0.8)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)
robot.move_to(via_pose, 0.8)
robot.move_to(approach_pose, 0.8)
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10), 0.5)
