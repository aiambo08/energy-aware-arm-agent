def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue_cube = find_cube(detections, "blue")

# If not found or incomplete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube

# If still not found, try another observation pose
if blue_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue")

# If still not found, abort (but task states there are 3 cubes including blue)
if blue_cube is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
    place_z = 0.0225  # resting on table
    place = Pose(-0.529, -0.172, place_z, blue_cube.yaw_rad)
    
    # Plan approach: go around the wall by moving via a safe waypoint above
    # Since wall is at x=-0.456, y=-0.020, we go via x=-0.60, y=-0.172 to avoid it
    safe_waypoint = Pose(-0.60, -0.172, 0.15)
    
    # Move above pick position
    robot.move_to(pick.above(0.10))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    
    # Move via safe waypoint to avoid wall
    robot.move_to(safe_waypoint)
    robot.move_to(place.above(0.10))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.10))
