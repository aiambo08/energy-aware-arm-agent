def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue_cube = find_cube(detections, "blue")

# If blue cube not found or not complete, move to observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube

# If still not found, try another observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube

# If still not found, try last observation pose
if blue_cube is None or not blue_cube.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue")

# If we found the blue cube, plan the move
if blue_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")

# Target position for placing the cube
target_x = -0.354
target_y = -0.004
target_z = 0.0225  # Cube resting on table

# Create pick and place poses
pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
place_pose = Pose(target_x, target_y, target_z, blue_cube.yaw_rad)

# Approach from above, avoiding the wall by going around
# First lift point above pick
lift_pose = pick_pose.above(0.10)

# Intermediate waypoint to avoid the wall
# Go to a safe y position first, then move in x
waypoint = Pose(-0.30, target_y, 0.15)

# Move to pick position
robot.move_to(lift_pose)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(lift_pose, 0.5)

# Move via waypoint to avoid the wall
robot.move_to(waypoint)
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10))
