def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose at near edge
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If still not found, try the last observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow")

# If we found the yellow cube, proceed to move it
if target is not None:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.374, -0.081, pick_pose.z, pick_pose.yaw)

    # Approach from above, avoiding the wall by going higher
    approach_height = 0.15  # Go higher to avoid wall
    lift_height = pick_pose.above(0.10)

    # Move above the cube
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(lift_height, 0.5)
    
    # Move above the goal position
    robot.move_to(place_pose.above(approach_height))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(approach_height))
