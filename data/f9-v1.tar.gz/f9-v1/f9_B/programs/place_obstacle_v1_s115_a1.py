def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation pose
if target is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green")

# If we don't have the green cube, we cannot complete
if target is None:
    robot.reset()
else:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.365, -0.199, pick_pose.z, pick_pose.yaw)

    # Approach from above, avoiding the wall by going around
    # Since wall is at x=-0.415, y=-0.090, we go via y=-0.25 to avoid
    safe_waypoint = Pose(-0.45, -0.25, 0.15)
    
    # Move above pick position
    robot.move_to(pick_pose.above(0.10), 0.8)
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)
    
    # Move via safe waypoint to avoid wall
    robot.move_to(safe_waypoint, 0.8)
    robot.move_to(place_pose.above(0.10), 0.8)
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(0.10), 0.8)
