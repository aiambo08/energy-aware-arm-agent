def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, try last observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If we don't have the red cube, we cannot proceed
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.401, -0.195, pick_pose.z, pick_pose.yaw)

    # Plan path to avoid wall: go north first, then east, then south
    # Intermediate point to go around wall (north of it, y > 0.05)
    mid_pose1 = Pose(-0.30, 0.15, 0.20)  # high above table
    mid_pose2 = Pose(-0.401, 0.15, 0.20)  # above target x, north of wall
    mid_pose3 = Pose(-0.401, 0.05, 0.20)  # clear of wall

    # Move above pick position
    robot.move_to(pick_pose.above(0.10), 0.7)
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)

    # Move around wall via intermediate points
    robot.move_to(mid_pose1, 0.7)
    robot.move_to(mid_pose2, 0.7)
    robot.move_to(mid_pose3, 0.7)

    # Descend to place
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()

    # Lift up
    robot.move_to(place_pose.above(0.10), 0.5)
