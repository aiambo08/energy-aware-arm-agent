def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If not found or incomplete, move to observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, try another observation pose
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "green") or target

# If still not found, fail gracefully (but task states there are 3 cubes including green)
if target is None:
    robot.reset()
else:
    pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_pose = Pose(-0.379, 0.198, pick_pose.z, pick_pose.yaw)

    # Approach from above, avoiding wall by going higher
    approach_height = 0.15  # 15 cm high to clear wall (10 cm)
    lift_height = pick_pose.above(0.10)

    # Move above pick position at safe height
    robot.move_to(pick_pose.above(approach_height))
    # Descend to pick
    robot.move_to(pick_pose, 0.5)
    # Grasp
    robot.grasp()
    # Lift up to safe height
    robot.move_to(lift_height, 0.5)
    # Move above place position
    robot.move_to(place_pose.above(approach_height))
    # Descend to just above table
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release
    robot.release()
    # Lift slightly after release
    robot.move_to(place_pose.above(0.10))
