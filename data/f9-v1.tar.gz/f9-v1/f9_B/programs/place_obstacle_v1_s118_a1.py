def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect("yellow")
d = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose
if d is None or not d.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("yellow")
    d = find_cube(detections, "yellow") or d
    if d is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect("yellow")
        d = find_cube(detections, "yellow") or d

# If still not found, fail
if d is None:
    raise PrimitiveError("code": "NO_YELLOW", "message": "Yellow cube not found")

# Define pick and place poses
pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
place = Pose(-0.613, 0.156, pick.z)

# Plan path to avoid wall: go via a high intermediate point
via_x = -0.65  # Go around the wall from the side away from the wall center
via_y = 0.25   # Wider arc to avoid wall
via = Pose(via_x, via_y, 0.25, pick.yaw_rad)

# Approach from above
approach_height = 0.10
lift_height = 0.10

# Move to pick position via high arc
robot.move_to(pick.above(approach_height))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(lift_height), 0.5)

# Move via high arc to avoid wall
robot.move_to(via)
robot.move_to(place.above(lift_height))

# Place the cube
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(lift_height))
