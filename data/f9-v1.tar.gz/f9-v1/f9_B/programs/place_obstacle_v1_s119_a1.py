def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First attempt to detect from ready pose
detections = robot.detect()
target = find_cube(detections, "yellow")

# If not found or incomplete, move to observation pose on the side
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If still not found, try the other side
if target is None or not target.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    target = find_cube(detections, "yellow") or target

# If we have a detection, proceed to move the cube
if target is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not found")

# Define pick and place poses
pick_pose = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_pose = Pose(-0.589, -0.179, pick_pose.z, target.yaw_rad)

# Approach from above, grasp, lift
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Move to above the target location, avoiding the wall by going higher
robot.move_to(place_pose.above(0.15))  # Go higher to clear the wall
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_pose.above(0.10))
