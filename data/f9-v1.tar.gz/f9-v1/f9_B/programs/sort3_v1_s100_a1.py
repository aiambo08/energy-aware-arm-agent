def get_detections():
    try:
        return robot.detect()
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect()

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(detection, target_x, target_y):
    if detection is None:
        return
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    place_z = 0.0225  # Cube center height when resting on table
    place = Pose(target_x, target_y, place_z, pick.yaw)
    
    # Approach from above
    approach_height = 0.10
    robot.move_to(pick.above(approach_height))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(approach_height), 0.5)
    
    # Move to target location
    robot.move_to(place.above(approach_height))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(approach_height))

# Define target positions
targets = {
    "green": (-0.388, 0.195),
    "yellow": (-0.598, 0.050),
    "blue": (-0.644, -0.083)
}

# Get initial detections
detections = get_detections()

# Move each cube to its target position
for color, (target_x, target_y) in targets.items():
    cube = find_cube(detections, color)
    move_cube_to_position(cube, target_x, target_y)
