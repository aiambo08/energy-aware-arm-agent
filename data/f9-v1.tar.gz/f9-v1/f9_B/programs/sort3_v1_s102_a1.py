def get_detections(target="any"):
    try:
        return robot.detect(target)
    except:
        return []

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_detection, target_x, target_y):
    if cube_detection is None:
        return
    pick_pose = Pose(cube_detection.position[0], cube_detection.position[1], 
                     cube_detection.position[2], cube_detection.yaw_rad)
    place_pose = Pose(target_x, target_y, pick_pose.z, cube_detection.yaw_rad)
    
    # Approach from above
    robot.move_to(pick_pose.above(0.10))
    # Descend slowly
    robot.move_to(pick_pose, 0.5)
    # Grasp
    robot.grasp()
    # Lift
    robot.move_to(pick_pose.above(0.10), 0.5)
    # Move to target location
    robot.move_to(place_pose.above(0.10))
    # Descend to place
    robot.move_to(place_pose.above(0.005), 0.5)
    # Release
    robot.release()
    # Retract
    robot.move_to(place_pose.above(0.10))

# Initial observation from a good vantage point
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = get_detections()

# Get specific cubes
yellow_cube = find_cube(detections, "yellow")
red_cube = find_cube(detections, "red")
blue_cube = find_cube(detections, "blue")

# Sort cubes to their target positions
# Using known target coordinates
yellow_target_x, yellow_target_y = -0.537, 0.018
red_target_x, red_target_y = -0.635, 0.157
blue_target_x, blue_target_y = -0.509, -0.149

# Move yellow cube
if yellow_cube:
    move_cube_to_position(yellow_cube, yellow_target_x, yellow_target_y)

# Move red cube
if red_cube:
    move_cube_to_position(red_cube, red_target_x, red_target_y)

# Move blue cube
if blue_cube:
    move_cube_to_position(blue_cube, blue_target_x, blue_target_y)
