def get_detections():
    try:
        return robot.detect()
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect()

def move_cube(detection, target_x, target_y):
    if detection is None:
        return
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    place = Pose(target_x, target_y, pick.z)
    try:
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        pass

detections = get_detections()

blue_target = (-0.490, -0.148)
green_target = (-0.577, -0.023)
red_target = (-0.380, 0.199)

blue_cube = next((d for d in detections if d.color == "blue"), None)
green_cube = next((d for d in detections if d.color == "green"), None)
red_cube = next((d for d in detections if d.color == "red"), None)

if blue_cube:
    move_cube(blue_cube, blue_target[0], blue_target[1])
if green_cube:
    move_cube(green_cube, green_target[0], green_target[1])
if red_cube:
    move_cube(red_cube, red_target[0], red_target[1])
