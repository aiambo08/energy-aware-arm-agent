def get_detections(target="any"):
    try:
        return robot.detect(target)
    except CameraTimeout:
        return ()

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_det, target_x, target_y):
    if cube_det is None or not cube_det.complete:
        return False
    
    pick_pose = Pose(cube_det.position[0], cube_det.position[1], cube_det.position[2], cube_det.yaw_rad)
    place_pose = Pose(target_x, target_y, pick_pose.z, cube_det.yaw_rad)
    
    try:
        robot.move_to(pick_pose.above(0.10), 0.8)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(0.10), 0.5)
        robot.move_to(place_pose.above(0.10), 0.8)
        robot.move_to(place_pose.above(0.005), 0.5)
        robot.release()
        robot.move_to(place_pose.above(0.10), 0.8)
        return True
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        return False

# Initial observation from a good viewpoint
robot.move_to(Pose(-0.30, 0.0, 0.15))

detections = get_detections()

# Sort yellow cube
yellow_cube = find_cube(detections, "yellow")
move_cube_to_position(yellow_cube, -0.395, -0.008)

# Re-detect after moving yellow
detections = get_detections()

# Sort blue cube
blue_cube = find_cube(detections, "blue")
move_cube_to_position(blue_cube, -0.573, -0.001)

# Re-detect after moving blue
detections = get_detections()

# Sort green cube
green_cube = find_cube(detections, "green")
move_cube_to_position(green_cube, -0.642, -0.141)
