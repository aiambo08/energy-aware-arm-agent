targets = {
    "yellow": Pose(-0.428, -0.105, 0.0225),
    "green": Pose(-0.646, 0.149, 0.0225),
    "red": Pose(-0.445, -0.005, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect("any")

def approach_grasp_lift(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    robot.move_to(pick.above(0.10))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    return pick

def place_at(pose):
    robot.move_to(pose.above(0.10))
    robot.move_to(pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(pose.above(0.10))

detections = get_detections()
moved = []

for color in targets.keys():
    det = next((d for d in detections if d.color == color and not any(m[0] == d for m in moved)), None)
    if det is None:
        continue
        
    try:
        pick_pose = approach_grasp_lift(det)
        place_at(targets[color])
        moved.append((det, pick_pose))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        try:
            robot.move_to(Pose(-0.30, 0.0, 0.15))
            new_dets = robot.detect(color)
            if new_dets:
                        det = new_dets[0]
                        pick_pose = approach_grasp_lift(det)
                        place_at(targets[color])
                        moved.append((det, pick_pose))
        except:
            pass

robot.move_to(Pose(-0.50, 0.0, 0.25))
