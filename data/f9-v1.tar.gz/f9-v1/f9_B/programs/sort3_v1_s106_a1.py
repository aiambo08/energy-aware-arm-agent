def get_detections():
    try:
        return robot.detect()
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect()

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_det, target_x, target_y):
    if cube_det is None:
        return
    pick = Pose(cube_det.position[0], cube_det.position[1], cube_det.position[2], cube_det.yaw_rad)
    place = Pose(target_x, target_y, pick.z, pick.yaw)
    try:
        robot.move_to(pick.above(0.10), 0.8)
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10), 0.8)
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10), 0.8)
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        pass

detections = get_detections()

yellow_cube = find_cube(detections, "yellow")
green_cube = find_cube(detections, "green")
blue_cube = find_cube(detections, "blue")

move_cube_to_position(yellow_cube, -0.650, 0.039)
move_cube_to_position(green_cube, -0.352, 0.151)
move_cube_to_position(blue_cube, -0.501, -0.083)
