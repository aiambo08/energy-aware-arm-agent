def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect(target)
    return dets[0] if dets else None

blue_dest = Pose(-0.384, -0.035, 0.0225)
red_dest = Pose(-0.412, 0.121, 0.0225)
yellow_dest = Pose(-0.489, 0.198, 0.0225)

destinations = {
    "blue": blue_dest,
    "red": red_dest,
    "yellow": yellow_dest
}

for color in ["blue", "red", "yellow"]:
    d = get_detection(color)
    if d is None:
        continue
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = destinations[color]
    try:
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        continue
