def get_detections(target="any"):
    try:
        return robot.detect(target)
    except:
        return []

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_det, target_x, target_y):
    if cube_det is None:
        return
    pick_pose = Pose(cube_det.position[0], cube_det.position[1], cube_det.position[2], cube_det.yaw_rad)
    place_pose = Pose(target_x, target_y, pick_pose.z, pick_pose.yaw)
    approach_height = 0.10
    lift_height = 0.10
    release_height = 0.005
    
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(lift_height), 0.5)
    robot.move_to(place_pose.above(lift_height))
    robot.move_to(place_pose.above(release_height), 0.5)
    robot.release()
    robot.move_to(place_pose.above(lift_height))

# Target positions
blue_target = (-0.541, 0.167)
red_target = (-0.352, -0.108)
green_target = (-0.628, 0.019)

# First observation from a good viewpoint
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = get_detections()

# Find cubes
blue_cube = find_cube(detections, "blue")
red_cube = find_cube(detections, "red")
green_cube = find_cube(detections, "green")

# If any cube is missing, try another viewpoint
if blue_cube is None or red_cube is None or green_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    additional_dets = get_detections()
    if blue_cube is None:
        blue_cube = find_cube(additional_dets, "blue") or blue_cube
    if red_cube is None:
        red_cube = find_cube(additional_dets, "red") or red_cube
    if green_cube is None:
        green_cube = find_cube(additional_dets, "green") or green_cube

# Move each cube to its target position
move_cube_to_position(blue_cube, blue_target[0], blue_target[1])
move_cube_to_position(red_cube, red_target[0], red_target[1])
move_cube_to_position(green_cube, green_target[0], green_target[1])
