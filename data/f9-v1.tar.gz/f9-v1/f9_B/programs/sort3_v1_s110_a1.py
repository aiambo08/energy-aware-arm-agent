def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    # Move to observation pose if not detected initially
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose, 0.7)
            dets = robot.detect(target)
            if dets:
                return dets[0]
        except:
            continue
    return None

# Target positions for each color
targets = {
    "green": Pose(-0.536, -0.145, 0.0225),
    "blue": Pose(-0.354, -0.025, 0.0225),
    "red": Pose(-0.370, 0.133, 0.0225)
}

# Process each color
for color, place_pose in targets.items():
    # Detect cube of current color
    d = get_detection(color)
    if d is None:
        continue  # Skip if not found
    
    # Create pick pose at cube center with detected yaw
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    
    # Approach from above, grasp, lift
    approach_pick = pick_pose.above(0.10)
    lift_pick = pick_pose.above(0.10)
    approach_place = place_pose.above(0.10)
    release_place = place_pose.above(0.005)
    
    try:
        robot.move_to(approach_pick, 0.8)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(lift_pick, 0.5)
        
        # Move to target location and release
        robot.move_to(approach_place, 0.8)
        robot.move_to(release_place, 0.5)
        robot.release()
        robot.move_to(approach_place, 0.5)
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        # If something goes wrong, continue with next cube
        continue

# Return to ready pose
robot.move_to(Pose(-0.50, 0.0, 0.25))
