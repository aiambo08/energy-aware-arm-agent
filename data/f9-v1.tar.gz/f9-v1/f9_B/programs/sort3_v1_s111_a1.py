def get_detections():
    dets = robot.detect()
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect()
    return dets

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_det, target_x, target_y):
    pick = Pose(cube_det.position[0], cube_det.position[1], cube_det.position[2], cube_det.yaw_rad)
    place_z = 0.0225  # Cube center height when resting on table
    place = Pose(target_x, target_y, place_z, cube_det.yaw_rad)
    
    # Approach from above
    robot.move_to(pick.above(0.10), 0.8)
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    
    # Move to target location
    robot.move_to(place.above(0.10), 0.8)
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.10), 0.5)

# Target positions
targets = {
    "green": (-0.475, 0.018),
    "yellow": (-0.388, 0.126),
    "blue": (-0.641, 0.102)
}

# Get all cube detections
detections = get_detections()

# Sort each cube to its target position
for color, (target_x, target_y) in targets.items():
    cube = find_cube(detections, color)
    if cube is not None:
        move_cube_to_position(cube, target_x, target_y)
        # Refresh detections after moving a cube
        detections = robot.detect()
