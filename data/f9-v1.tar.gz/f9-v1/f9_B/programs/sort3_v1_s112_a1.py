targets = {
    "green": Pose(-0.353, -0.006, 0.0225),
    "red": Pose(-0.636, -0.155, 0.0225),
    "yellow": Pose(-0.467, 0.049, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect("any")

def move_cube(detection, target_pose):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach_height = 0.10
    lift_height = 0.10
    release_height = 0.005
    
    robot.move_to(pick.above(approach_height))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)
    robot.move_to(target_pose.above(lift_height))
    robot.move_to(target_pose.above(release_height), 0.5)
    robot.release()
    robot.move_to(target_pose.above(lift_height))

detections = get_detections()
moved = []

for color in ["green", "red", "yellow"]:
    target = targets[color]
    candidates = [d for d in detections if d.color == color]
    if not candidates:
        continue
    best_det = candidates[0]
    pick_pos = Pose(best_det.position[0], best_det.position[1], best_det.position[2])
    if pick_pos.distance_xy(target) > 0.01:
        move_cube(best_det, target)
        moved.append(color)

remaining_colors = set(["green", "red", "yellow"]) - set(moved)
if remaining_colors:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("any")
    for color in remaining_colors:
        target = targets[color]
        candidates = [d for d in detections if d.color == color]
        if candidates:
            move_cube(candidates[0], target)
