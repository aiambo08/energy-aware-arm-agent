def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect(target)
    return dets[0] if dets else None

def move_cube(color, target_x, target_y):
    d = get_detection(color)
    if d is None:
        return
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = Pose(target_x, target_y, pick.z)
    robot.move_to(pick.above(0.10))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    robot.move_to(place.above(0.10))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.10))

move_cube("blue", -0.616, -0.147)
move_cube("yellow", -0.496, -0.102)
move_cube("red", -0.362, 0.176)
