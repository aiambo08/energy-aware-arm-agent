def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect(target)
    return dets[0] if dets else None

def move_cube(color, target_x, target_y):
    d = get_detection(color)
    if d is None:
        return False
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = Pose(target_x, target_y, pick.z)
    try:
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
        return True
    except:
        return False

move_cube("red", -0.487, -0.154)
move_cube("green", -0.565, 0.185)
move_cube("blue", -0.617, 0.077)
