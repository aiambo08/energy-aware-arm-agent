def get_detections(target="any"):
    try:
        return robot.detect(target)
    except:
        return ()

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_cube_to_position(cube_det, target_pos):
    if cube_det is None:
        return
    pick_pose = Pose(cube_det.position[0], cube_det.position[1], cube_det.position[2], cube_det.yaw_rad)
    place_pose = Pose(target_pos[0], target_pos[1], pick_pose.z, cube_det.yaw_rad)
    approach_height = 0.10
    lift_height = 0.10
    release_height = 0.005
    
    try:
        robot.move_to(pick_pose.above(approach_height))
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(lift_height), 0.5)
        robot.move_to(place_pose.above(lift_height))
        robot.move_to(place_pose.above(release_height), 0.5)
        robot.release()
        robot.move_to(place_pose.above(lift_height))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        pass

# Target positions in metres (x, y)
targets = {
    "red": (-0.540, 0.188),
    "yellow": (-0.398, -0.046),
    "green": (-0.427, -0.166)
}

# First observation from a clear view
observation_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
detections = []

for obs_pose in observation_poses:
    try:
        robot.move_to(obs_pose)
        new_dets = get_detections()
        detections.extend(new_dets)
        if len(detections) >= 3:
            break
    except:
        continue

# If we don't have all cubes, try from ready pose
if len(detections) < 3:
    try:
        robot.move_to(Pose(-0.50, 0.0, 0.25))
        new_dets = get_detections()
        detections = new_dets  # Replace with latest
    except:
        pass

# Process each target color
for color, target_pos in targets.items():
    cube = find_cube(detections, color)
    move_cube_to_position(cube, target_pos)
