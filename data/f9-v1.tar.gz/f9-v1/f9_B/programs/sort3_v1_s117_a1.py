def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect(target)
    return dets[0] if dets else None

blue_dest = Pose(-0.628, -0.133, 0.0225)
red_dest = Pose(-0.601, 0.162, 0.0225)
green_dest = Pose(-0.477, 0.162, 0.0225)

colors = ["blue", "red", "green"]
destinations = [blue_dest, red_dest, green_dest]

for color, dest in zip(colors, destinations):
    det = get_detection(color)
    if det is None:
        continue
        
    pick_pose = Pose(det.position[0], det.position[1], det.position[2], det.yaw_rad)
    
    robot.move_to(pick_pose.above(0.10))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)
    
    robot.move_to(dest.above(0.10))
    robot.move_to(dest.above(0.005), 0.5)
    robot.release()
    robot.move_to(dest.above(0.10))
