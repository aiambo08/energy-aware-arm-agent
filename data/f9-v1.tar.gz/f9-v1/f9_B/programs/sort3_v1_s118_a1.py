def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    # Move to observation pose and try again
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        try:
            robot.move_to(obs_pose, 0.7)
            dets = robot.detect(target)
            if dets:
                return dets[0]
        except:
            continue
    return None

# Target positions for each color
targets = {
    "green": Pose(-0.578, 0.070, 0.0225),
    "yellow": Pose(-0.540, -0.042, 0.0225),
    "red": Pose(-0.626, 0.197, 0.0225)
}

# Detect all cubes
detections = robot.detect("any")
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("any")

# Group detections by color
detections_by_color = {}
for d in detections:
    detections_by_color[d.color] = d

# Process each color
for color, target_pose in targets.items():
    if color not in detections_by_color:
        continue
    d = detections_by_color[color]
    
    # Create pick pose
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    
    # Approach from above
    approach_pick = pick_pose.above(0.10)
    approach_place = target_pose.above(0.10)
    
    try:
        robot.move_to(approach_pick, 0.7)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(approach_pick, 0.5)
        robot.move_to(approach_place, 0.7)
        robot.move_to(target_pose.above(0.005), 0.5)
        robot.release()
        robot.move_to(approach_place, 0.5)
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        # If something goes wrong, continue with next cube
        continue
