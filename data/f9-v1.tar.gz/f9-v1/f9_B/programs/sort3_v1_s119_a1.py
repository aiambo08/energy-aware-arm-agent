def get_detections():
    try:
        return robot.detect()
    except:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        return robot.detect()

def move_cube(detection, target_x, target_y):
    if detection is None:
        return
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    place = Pose(target_x, target_y, pick.z)
    try:
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
    except:
        pass

detections = get_detections()

yellow_target = (-0.388, -0.049)
red_target = (-0.530, -0.147)
blue_target = (-0.457, 0.038)

yellow_det = next((d for d in detections if d.color == "yellow"), None)
red_det = next((d for d in detections if d.color == "red"), None)
blue_det = next((d for d in detections if d.color == "blue"), None)

if yellow_det:
    move_cube(yellow_det, yellow_target[0], yellow_target[1])
if red_det:
    move_cube(red_det, red_target[0], red_target[1])
if blue_det:
    move_cube(blue_det, blue_target[0], blue_target[1])
