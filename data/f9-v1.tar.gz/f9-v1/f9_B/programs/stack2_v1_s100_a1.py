def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, observe from a good viewpoint to see all cubes
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = robot.detect()

# Find red and green cubes
red_cube = find_cube(detections, "red")
green_cube = find_cube(detections, "green")

if red_cube is None or green_cube is None:
    # If we can't see both, try another viewpoint
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    if green_cube is None:
        green_cube = find_cube(detections, "green")
    
    if red_cube is None or green_cube is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect()
        if red_cube is None:
            red_cube = find_cube(detections, "red")
        if green_cube is None:
            green_cube = find_cube(detections, "green")

# If still missing either cube, fail
if red_cube is None or green_cube is None:
    robot.reset()
else:
    # Target position: red cube on top of green cube, centered
    target_z = green_cube.position[2] + 0.045  # One cube height higher
    place_pose = Pose(green_cube.position[0], green_cube.position[1], target_z, red_cube.yaw_rad)
    
    # Pick up the red cube
    pick_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)
    approach_pick = pick_pose.above(0.10)
    approach_place = place_pose.above(0.10)
    
    try:
        robot.move_to(approach_pick)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(approach_pick, 0.5)
        
        # Place on green cube
        robot.move_to(approach_place)
        robot.move_to(place_pose.above(0.005), 0.5)
        robot.release()
        robot.move_to(approach_place, 0.5)
    except:
        robot.reset()
