def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from default pose
detections = robot.detect()
red_cube = find_cube(detections, "red")
blue_cube = find_cube(detections, "blue")

# If blue cube not found, move to observation pose to get better view
if blue_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue")

# If red cube not found, move to observation pose if not already there
if red_cube is None and blue_cube is not None:
    if len(detections) < 2:  # Likely still partial view
        robot.move_to(Pose(-0.30, 0.25, 0.15))
        detections = robot.detect()
        red_cube = find_cube(detections, "red")
        if red_cube is None:
            robot.move_to(Pose(-0.30, -0.25, 0.15))
            detections = robot.detect()
            red_cube = find_cube(detections, "red")

# If we can't find both cubes, fail gracefully
if red_cube is None or blue_cube is None:
    robot.reset()
    raise PrimitiveError("Not all cubes detected", "missing_cubes")

# Target grasp pose for red cube
red_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)

# Target place pose: on top of blue cube, centered
place_z = blue_cube.position[2] + 0.045  # Cube height
place_pose = Pose(blue_cube.position[0], blue_cube.position[1], place_z, red_pose.yaw)

# Pick up red cube
robot.move_to(red_pose.above(0.10))
robot.move_to(red_pose, 0.5)
robot.grasp()
robot.move_to(red_pose.above(0.10), 0.5)

# Place on blue cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_pose.above(0.10))
