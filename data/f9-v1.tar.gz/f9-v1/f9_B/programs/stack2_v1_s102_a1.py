def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from default pose
detections = robot.detect()
blue_cube = find_cube(detections, "blue")
red_cube = find_cube(detections, "red")

# If red or blue cube not found or incomplete, move to observation pose
if blue_cube is None or red_cube is None or not blue_cube.complete or not red_cube.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube
    red_cube = find_cube(detections, "red") or red_cube

# If still missing, try another observation pose
if blue_cube is None or red_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if blue_cube is None:
        blue_cube = find_cube(detections, "blue")
    if red_cube is None:
        red_cube = find_cube(detections, "red")

# Final fallback: use incomplete detection if needed
if blue_cube is None or red_cube is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    if blue_cube is None:
        blue_cube = find_cube(detections, "blue")
    if red_cube is None:
        red_cube = find_cube(detections, "red")

# If either cube still not found, we cannot complete
if blue_cube is None or red_cube is None:
    robot.reset()
    raise PrimitiveError("code": "MISSING_CUBE", "message": "Could not detect blue or red cube")

# Define pick and place poses
pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
# Place on top of red cube, centered, with z = red cube top (z + 0.045)
place_z = red_cube.position[2] + 0.045
place_pose = Pose(red_cube.position[0], red_cube.position[1], place_z, blue_cube.yaw_rad)

# Pick up blue cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place on red cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_pose.above(0.10))
