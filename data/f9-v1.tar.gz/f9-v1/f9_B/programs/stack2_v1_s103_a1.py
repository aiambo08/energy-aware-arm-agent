def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red_cube = find_cube(detections, "red")
green_cube = find_cube(detections, "green")

# If green cube not found, move to observation pose
if green_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green_cube = find_cube(detections, "green")

# If red cube not found or partial, move to better view
if red_cube is None or not red_cube.complete:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("red")
    red_cube = find_cube(detections, "red") or red_cube

# If still not found, try last observation pose
if red_cube is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect("red")
    red_cube = find_cube(detections, "red")

# Prepare pick and place poses
if red_cube is None or green_cube is None:
    robot.reset()
else:
    pick_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)
    # Target z for placing on green cube: green cube's top surface + half red cube height
    place_z = green_cube.position[2] + 0.045
    place_pose = Pose(green_cube.position[0], green_cube.position[1], place_z, red_cube.yaw_rad)
    
    # Pick up red cube
    robot.move_to(pick_pose.above(0.10))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)
    
    # Place on green cube
    robot.move_to(place_pose.above(0.10))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(0.10))
