def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue = find_cube(detections, "blue")
red = find_cube(detections, "red")

# If red or blue not found, move to observation pose and detect again
if blue is None or red is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    red = find_cube(detections, "red") or red

# If still missing, try another observation pose
if blue is None or red is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    red = find_cube(detections, "red") or red

# If still missing, try last observation pose
if blue is None or red is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    red = find_cube(detections, "red") or red

# If either cube still not found, fail
if blue is None:
    raise PrimitiveError("code": "NO_BLUE", "message": "Blue cube not found")
if red is None:
    raise PrimitiveError("code": "NO_RED", "message": "Red cube not found")

# Define grasp and place poses
grasp_pose = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Place on top of red cube, centered, with same yaw as red cube
place_z = red.position[2] + 0.045  # 4.5 cm cube height
place_pose = Pose(red.position[0], red.position[1], place_z, red.yaw_rad)

# Pick up blue cube
robot.move_to(grasp_pose.above(0.10))
robot.move_to(grasp_pose, 0.5)
robot.grasp()
robot.move_to(grasp_pose.above(0.10), 0.5)

# Place on red cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_pose.above(0.10))
