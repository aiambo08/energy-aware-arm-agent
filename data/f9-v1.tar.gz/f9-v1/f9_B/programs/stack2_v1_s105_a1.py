def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Detect all cubes
detections = robot.detect()
blue = find_cube(detections, "blue")
yellow = find_cube(detections, "yellow")

if blue is None or yellow is None:
    # Move to a better observation pose if needed
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue")
    yellow = find_cube(detections, "yellow")

# Ensure we found both cubes
if blue is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")
if yellow is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not found")

# Define pick and place poses
pick_pose = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Target place is above yellow cube center, at height of yellow cube top face + half blue cube height
target_z = yellow.position[2] + 0.045  # since cube height is 0.045 m (4.5 cm)
place_pose = Pose(yellow.position[0], yellow.position[1], target_z, blue.yaw_rad)

# Pick up the blue cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place blue cube on yellow cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_pose.above(0.10))
