def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Detect all cubes
detections = robot.detect()
green_cube = find_cube(detections, "green")
blue_cube = find_cube(detections, "blue")

if green_cube is None or blue_cube is None:
    # Move to a better observation pose if needed
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green_cube = find_cube(detections, "green")
    blue_cube = find_cube(detections, "blue")

if green_cube is None:
    raise PrimitiveError("No green cube detected")
if blue_cube is None:
    raise PrimitiveError("No blue cube detected")

# Define pick and place poses
pick_pose = Pose(green_cube.position[0], green_cube.position[1], green_cube.position[2], green_cube.yaw_rad)
# Target place is centered on blue cube, one cube height higher
place_z = blue_cube.position[2] + 0.045  # 4.5 cm higher
place_pose = Pose(blue_cube.position[0], blue_cube.position[1], place_z, green_cube.yaw_rad)

# Pick the green cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place on blue cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10))
