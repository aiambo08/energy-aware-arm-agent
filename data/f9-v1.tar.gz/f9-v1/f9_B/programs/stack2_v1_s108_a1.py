def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from default pose
detections = robot.detect()
green = find_cube(detections, "green")
yellow = find_cube(detections, "yellow")

# If either cube is missing or partial, move to observation pose
if green is None or yellow is None or not green.complete or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    yellow = find_cube(detections, "yellow") or yellow

# Define pick and place poses for green cube
pick_green = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
# Place green cube on top of yellow, centered, with height increased by one cube
place_height = yellow.position[2] + 0.045  # 4.5 cm cube height
place_green = Pose(yellow.position[0], yellow.position[1], place_height, green.yaw_rad)

# Pick up green cube
robot.move_to(pick_green.above(0.10))
robot.move_to(pick_green, 0.5)
robot.grasp()
robot.move_to(pick_green.above(0.10), 0.5)

# Place on yellow cube
robot.move_to(place_green.above(0.10))
robot.move_to(place_green.above(0.005), 0.5)
robot.release()
robot.move_to(place_green.above(0.10))
