def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, observe from a good viewpoint to see all cubes
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = robot.detect()

# Find red and blue cubes
red_cube = find_cube(detections, "red")
blue_cube = find_cube(detections, "blue")

if red_cube is None or blue_cube is None:
    # If not found, try another viewpoint
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("red") + robot.detect("blue")
    red_cube = find_cube(detections, "red") or red_cube
    blue_cube = find_cube(detections, "blue") or blue_cube

if red_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")
if blue_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")

# Define pick and place poses
pick_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)
# Target z for top of blue cube: blue cube center z + half height (0.0225) + red cube half height (0.0225)
target_z = blue_cube.position[2] + 0.045
place_pose = Pose(blue_cube.position[0], blue_cube.position[1], target_z, red_cube.yaw_rad)

# Pick up the red cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place on top of blue cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10))
