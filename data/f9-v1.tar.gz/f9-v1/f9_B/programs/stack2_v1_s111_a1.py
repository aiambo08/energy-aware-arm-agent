def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue = find_cube(detections, "blue")
green = find_cube(detections, "green")

# If needed, move to observation pose to get better view
if blue is None or green is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

# If still missing either cube, try another observation pose
if blue is None or green is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

# If still missing, try last observation pose
if blue is None or green is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

# If we don't have both cubes, we cannot complete the task
if blue is None or green is None:
    robot.reset()
    raise PrimitiveError("code": "MISSING_CUBE", "message": "Could not detect both blue and green cubes")

# Define pick and place poses
pick_blue = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Place blue cube on top of green cube, centered
place_z = green.position[2] + 0.045  # Cube height in meters
place_blue = Pose(green.position[0], green.position[1], place_z, blue.yaw_rad)

# Pick up blue cube
approach_height = 0.10
robot.move_to(pick_blue.above(approach_height))
robot.move_to(pick_blue, 0.5)
robot.grasp()
robot.move_to(pick_blue.above(approach_height), 0.5)

# Place blue cube on green cube
robot.move_to(place_blue.above(approach_height))
robot.move_to(place_blue.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_blue.above(approach_height))
