def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from default pose
detections = robot.detect()
green = find_cube(detections, "green")
red = find_cube(detections, "red")

# If red or green not found or incomplete, move to observation pose
if green is None or red is None or not green.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    red = find_cube(detections, "red") or red

# If still missing, try another view
if green is None or red is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if green is None:
        green = find_cube(detections, "green")
    if red is None:
        red = find_cube(detections, "red")

# Final check
if green is None or red is None:
    raise PrimitiveError("MissingCubes", "Could not detect both green and red cubes")

# Pick green cube
pick_green = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
# Place green on top of red, centered
place_z = red.position[2] + 0.045  # One cube height higher
place_green = Pose(red.position[0], red.position[1], place_z, green.yaw_rad)

# Pick up green cube
robot.move_to(pick_green.above(0.10))
robot.move_to(pick_green, 0.5)
robot.grasp()
robot.move_to(pick_green.above(0.10), 0.5)

# Move and place on red
robot.move_to(place_green.above(0.10))
robot.move_to(place_green.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_green.above(0.10))
