def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, detect all cubes
detections = robot.detect()

# If we can't see the red or yellow cube clearly, move to a better observation pose
red_cube = find_cube(detections, "red")
yellow_cube = find_cube(detections, "yellow")

if red_cube is None or yellow_cube is None or not yellow_cube.complete:
    # Move to a view pose that minimizes arm shadow
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red_cube = find_cube(detections, "red")
    yellow_cube = find_cube(detections, "yellow")

# If still missing either cube, try another view
if red_cube is None or yellow_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    if yellow_cube is None:
        yellow_cube = find_cube(detections, "yellow")

# If still missing, try last view
if red_cube is None or yellow_cube is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    if yellow_cube is None:
        yellow_cube = find_cube(detections, "yellow")

# If we still don't have both cubes, we proceed with best available (yellow must be found)
if yellow_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not found")

if red_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")

# Define pick and place poses
pick_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)
# Target height for placing red cube on yellow: yellow cube top surface (z = yellow_cube.position[2] + 0.045)
place_z = yellow_cube.position[2] + 0.045
place_pose = Pose(yellow_cube.position[0], yellow_cube.position[1], place_z, red_cube.yaw_rad)

# Pick up the red cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place it on the yellow cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up slightly
robot.move_to(place_pose.above(0.10))
