def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detect all cubes
detections = robot.detect()
blue_cube = find_cube(detections, "blue")
red_cube = find_cube(detections, "red")

# If either cube is not found, move to a better observation pose and detect again
if blue_cube is None or red_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube
    red_cube = find_cube(detections, "red") or red_cube

# If we still don't have both cubes, try another view
if blue_cube is None or red_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue") or blue_cube
    red_cube = find_cube(detections, "red") or red_cube

# If we still don't have both cubes, try the last observation pose
if blue_cube is None or red_cube is None:
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    detections = robot.detect()
    blue_cube = find_cube(detections, "blue")
    red_cube = find_cube(detections, "red")

# If we can't find both cubes, we can't complete the task
if blue_cube is None or red_cube is None:
    robot.reset()
    raise PrimitiveError("code": "MISSING_CUBE", "message": "Could not detect both blue and red cubes")

# Define pick and place poses for blue cube
pick_pose = Pose(blue_cube.position[0], blue_cube.position[1], blue_cube.position[2], blue_cube.yaw_rad)
# Place the blue cube on top of the red cube, centered
place_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2] + 0.045, blue_cube.yaw_rad)

# Pick up the blue cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place the blue cube on top of the red cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up slightly
robot.move_to(place_pose.above(0.10))
