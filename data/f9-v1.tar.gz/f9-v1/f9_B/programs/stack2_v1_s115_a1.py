def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, observe from a good viewpoint to see all cubes
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = robot.detect()

# Find the green and red cubes
green_cube = find_cube(detections, "green")
red_cube = find_cube(detections, "red")

if green_cube is None or red_cube is None:
    # If we can't find both, try another viewpoint
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if green_cube is None:
        green_cube = find_cube(detections, "green")
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    
    if green_cube is None or red_cube is None:
        robot.move_to(Pose(-0.30, -0.25, 0.15))
        detections = robot.detect()
        if green_cube is None:
            green_cube = find_cube(detections, "green")
        if red_cube is None:
            red_cube = find_cube(detections, "red")

# If we still can't find both cubes, we can't complete the task
if green_cube is None or red_cube is None:
    robot.reset()
else:
    # Define pick and place poses
    pick_pose = Pose(green_cube.position[0], green_cube.position[1], green_cube.position[2], green_cube.yaw_rad)
    # Target place is center of red cube, but 0.045 m higher (cube height)
    place_z = red_cube.position[2] + 0.045
    place_pose = Pose(red_cube.position[0], red_cube.position[1], place_z, green_cube.yaw_rad)
    
    # Pick up the green cube
    robot.move_to(pick_pose.above(0.10))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(0.10), 0.5)
    
    # Place it on top of the red cube
    robot.move_to(place_pose.above(0.10))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(0.10))
