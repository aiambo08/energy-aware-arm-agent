def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red_cube = find_cube(detections, "red")
blue_cube = find_cube(detections, "blue")

# If needed, move to observation pose to see better
if red_cube is None or blue_cube is None:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    if blue_cube is None:
        blue_cube = find_cube(detections, "blue")

# If still missing, try another observation pose
if red_cube is None or blue_cube is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if red_cube is None:
        red_cube = find_cube(detections, "red")
    if blue_cube is None:
        blue_cube = find_cube(detections, "blue")

# Final check
if red_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")
if blue_cube is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")

# Prepare pick and place poses
pick_pose = Pose(red_cube.position[0], red_cube.position[1], red_cube.position[2], red_cube.yaw_rad)
# Target z for placing red cube on blue: blue cube's top center (z + height)
place_z = blue_cube.position[2] + 0.045
place_pose = Pose(blue_cube.position[0], blue_cube.position[1], place_z, red_cube.yaw_rad)

# Pick up red cube
robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)

# Place on blue cube
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_pose.above(0.10))
