def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, observe from a good viewpoint to see all cubes
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = robot.detect()

blue = find_cube(detections, "blue")
green = find_cube(detections, "green")

if blue is None or green is None:
    # If not found from first view, try another observation pose
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("blue") + robot.detect("green")
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

if blue is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")
if green is None:
    raise PrimitiveError("NoObjectGrasped", "Green cube not found")

# Define pick and place poses
pick_blue = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Place blue cube on top of green, centered at green's top center
place_height = green.position[2] + 0.045  # 4.5 cm cube height
place_blue = Pose(green.position[0], green.position[1], place_height, blue.yaw_rad)

# Pick up the blue cube
robot.move_to(pick_blue.above(0.10))
robot.move_to(pick_blue, 0.5)
robot.grasp()
robot.move_to(pick_blue.above(0.10), 0.5)

# Place it on the green cube
robot.move_to(place_blue.above(0.10))
robot.move_to(place_blue.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_blue.above(0.10))
