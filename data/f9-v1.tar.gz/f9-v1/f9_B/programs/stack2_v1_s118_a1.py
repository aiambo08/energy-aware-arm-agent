def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, observe from a good vantage point to see all cubes
robot.move_to(Pose(-0.30, 0.0, 0.15))
detections = robot.detect()

# Find red and green cubes
red_cube = find_cube(detections, "red")
green_cube = find_cube(detections, "green")

if red_cube is None or green_cube is None:
    # If not found, try another observation point
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("red") + robot.detect("green")
    red_cube = find_cube(detections, "red") or red_cube
    green_cube = find_cube(detections, "green") or green_cube

if red_cube is None:
    raise PrimitiveError("red", "Red cube not found")
if green_cube is None:
    raise PrimitiveError("green", "Green cube not found")

# Define pick and place poses
pick_green = Pose(green_cube.position[0], green_cube.position[1], green_cube.position[2], green_cube.yaw_rad)
# Place green cube on top of red cube, centered
place_z = red_cube.position[2] + 0.045  # 4.5 cm height of a cube
place_green = Pose(red_cube.position[0], red_cube.position[1], place_z, green_cube.yaw_rad)

# Pick up the green cube
robot.move_to(pick_green.above(0.10))
robot.move_to(pick_green, 0.5)
robot.grasp()
robot.move_to(pick_green.above(0.10), 0.5)

# Place it on the red cube
robot.move_to(place_green.above(0.10))
robot.move_to(place_green.above(0.005), 0.5)
robot.release()
robot.move_to(place_green.above(0.10))
