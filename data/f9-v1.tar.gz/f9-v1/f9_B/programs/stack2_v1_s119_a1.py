def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from default pose
detections = robot.detect()
yellow = find_cube(detections, "yellow")
red = find_cube(detections, "red")

# If red or yellow not found or incomplete, move to observation pose
if yellow is None or red is None or not yellow.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    yellow = find_cube(detections, "yellow") or yellow
    red = find_cube(detections, "red") or red

# If still missing, try another view
if yellow is None or red is None:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect()
    if yellow is None:
        yellow = find_cube(detections, "yellow") or yellow
    if red is None:
        red = find_cube(detections, "red") or red

# Final fallback: use incomplete detection if needed
if yellow is None or red is None:
    detections = robot.detect()
    if yellow is None:
        yellow = find_cube(detections, "yellow")
    if red is None:
        red = find_cube(detections, "red")

# If either is still missing, we cannot complete
if yellow is None or red is None:
    robot.reset()
    raise PrimitiveError("Missing required cubes")

# Define pick and place poses
pick_yellow = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
place_height = red.position[2] + 0.045  # Top of red cube
place_yellow = Pose(red.position[0], red.position[1], place_height, yellow.yaw_rad)

# Pick up yellow cube
robot.move_to(pick_yellow.above(0.10))
robot.move_to(pick_yellow, 0.5)
robot.grasp()
robot.move_to(pick_yellow.above(0.10), 0.5)

# Place on red cube
robot.move_to(place_yellow.above(0.10))
robot.move_to(place_yellow.above(0.005), 0.5)
robot.release()

# Lift up
robot.move_to(place_yellow.above(0.10))
