robot.execute_skill("pick_place_cube", color="green", x=-0.553, y=-0.191)
