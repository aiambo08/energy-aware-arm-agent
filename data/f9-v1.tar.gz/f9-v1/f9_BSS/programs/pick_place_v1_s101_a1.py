robot.execute_skill("pick_place_cube", color="red", x=-0.487, y=0.197)
