robot.execute_skill("pick_place_cube", color="blue", x=-0.573, y=0.046)
