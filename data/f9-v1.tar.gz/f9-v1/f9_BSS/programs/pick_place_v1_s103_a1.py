robot.execute_skill("pick_place_cube", color="yellow", x=-0.368, y=0.191)
