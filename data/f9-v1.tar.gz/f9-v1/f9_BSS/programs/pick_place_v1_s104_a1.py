robot.execute_skill("pick_place_cube", color="blue", x=-0.495, y=0.173)
