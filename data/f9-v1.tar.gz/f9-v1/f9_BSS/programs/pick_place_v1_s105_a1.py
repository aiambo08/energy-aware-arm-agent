robot.execute_skill("pick_place_cube", color="yellow", x=-0.528, y=-0.166)
