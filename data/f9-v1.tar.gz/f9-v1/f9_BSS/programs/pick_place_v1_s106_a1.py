robot.execute_skill("pick_place_cube", color="yellow", x=-0.593, y=0.021)
