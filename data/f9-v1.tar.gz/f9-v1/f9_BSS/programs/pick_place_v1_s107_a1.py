robot.execute_skill("pick_place_cube", color="red", x=-0.418, y=-0.166)
