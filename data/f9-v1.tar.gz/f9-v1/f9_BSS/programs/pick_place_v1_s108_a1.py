robot.execute_skill("pick_place_cube", color="blue", x=-0.382, y=0.143)
