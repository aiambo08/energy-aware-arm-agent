robot.execute_skill("pick_place_cube", color="red", x=-0.596, y=0.080)
