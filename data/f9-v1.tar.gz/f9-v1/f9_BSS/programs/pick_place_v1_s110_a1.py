robot.execute_skill("pick_place_cube", color="red", x=-0.522, y=-0.032)
