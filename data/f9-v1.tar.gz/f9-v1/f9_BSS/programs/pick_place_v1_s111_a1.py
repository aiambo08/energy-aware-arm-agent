robot.execute_skill("pick_place_cube", color="red", x=-0.389, y=0.061)
