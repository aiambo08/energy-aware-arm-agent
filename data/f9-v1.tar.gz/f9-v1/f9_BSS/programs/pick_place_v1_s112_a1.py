robot.execute_skill("pick_place_cube", color="yellow", x=-0.364, y=-0.062)
