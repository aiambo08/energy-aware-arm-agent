robot.execute_skill("pick_place_cube", color="red", x=-0.510, y=0.172)
