robot.execute_skill("pick_place_cube", color="yellow", x=-0.509, y=-0.153)
