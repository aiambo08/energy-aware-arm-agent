robot.execute_skill("pick_place_cube", color="blue", x=-0.518, y=0.187)
