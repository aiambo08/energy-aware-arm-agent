robot.execute_skill("pick_place_cube", color="blue", x=-0.558, y=0.131)
