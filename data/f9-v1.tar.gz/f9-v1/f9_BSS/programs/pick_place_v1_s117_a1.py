robot.execute_skill("pick_place_cube", color="green", x=-0.477, y=-0.003)
