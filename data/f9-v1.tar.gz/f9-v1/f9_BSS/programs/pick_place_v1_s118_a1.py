robot.execute_skill("pick_place_cube", color="red", x=-0.624, y=-0.181)
