robot.execute_skill("pick_place_cube", color="blue", x=-0.579, y=0.108)
