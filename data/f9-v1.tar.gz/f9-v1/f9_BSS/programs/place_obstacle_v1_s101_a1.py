robot.execute_skill("place_cube_over_wall", color="blue", x=-0.595, y=-0.111)
