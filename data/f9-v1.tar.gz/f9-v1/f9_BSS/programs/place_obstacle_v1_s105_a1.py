try:
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.566, y=0.142)
except SkillPreconditionFailed:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.566, y=0.142)
