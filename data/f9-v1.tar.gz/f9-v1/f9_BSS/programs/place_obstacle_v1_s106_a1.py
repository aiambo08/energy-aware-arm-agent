try:
    robot.execute_skill("place_cube_over_wall", color="red", x=-0.525, y=0.181)
except SkillPreconditionFailed:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    robot.execute_skill("place_cube_over_wall", color="red", x=-0.525, y=0.181)
