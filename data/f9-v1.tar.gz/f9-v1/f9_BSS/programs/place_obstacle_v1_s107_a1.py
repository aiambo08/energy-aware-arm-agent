try:
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.358, y=0.195)
except SkillPreconditionFailed:
    dets = robot.detect("yellow")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("yellow")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.358, y=0.195)
except (SkillPostconditionFailed, SkillFailed):
    robot.reset()
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.358, y=0.195)
