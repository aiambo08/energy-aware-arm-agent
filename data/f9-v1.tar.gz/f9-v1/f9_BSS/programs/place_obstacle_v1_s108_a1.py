try:
    robot.execute_skill("place_cube_over_wall", color="green", x=-0.394, y=0.076)
except SkillPreconditionFailed:
    dets = robot.detect("green")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("green")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="green", x=-0.394, y=0.076)
except (SkillPostconditionFailed, SkillFailed):
    d = None
    for d in robot.detect("green"):
        if d.complete:
            break
    if d is None:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("green")
        d = dets[0] if dets else None
        if d is None:
            raise PrimitiveError("No green cube detected")
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = Pose(-0.394, 0.076, pick.z)
    robot.move_to(pick.above(0.10))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    robot.move_to(place.above(0.10))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.10))
