robot.execute_skill("place_cube_over_wall", color="blue", x=-0.529, y=-0.172)
