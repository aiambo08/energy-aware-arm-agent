try:
    robot.execute_skill("place_cube_over_wall", color="blue", x=-0.354, y=-0.004)
except SkillPreconditionFailed:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    robot.execute_skill("place_cube_over_wall", color="blue", x=-0.354, y=-0.004)
