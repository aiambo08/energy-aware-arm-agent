try:
    robot.execute_skill("place_cube_over_wall", color="green", x=-0.365, y=-0.199)
except SkillPreconditionFailed:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    robot.execute_skill("place_cube_over_wall", color="green", x=-0.365, y=-0.199)
