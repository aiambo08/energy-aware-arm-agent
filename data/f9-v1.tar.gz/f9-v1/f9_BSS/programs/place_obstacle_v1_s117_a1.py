try:
    robot.execute_skill("place_cube_over_wall", color="green", x=-0.379, y=0.198)
except SkillPreconditionFailed:
    dets = robot.detect("green")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("green")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="green", x=-0.379, y=0.198)
except (SkillPostconditionFailed, SkillFailed):
    d = None
    for det in robot.detect("green"):
        if det.complete:
            d = det
            break
    if d is None:
        d = next(iter(robot.detect("green")), None)
    if d is None:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        d = next(iter(robot.detect("green")), None)
    if d is not None:
        pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
        place = Pose(-0.379, 0.198, d.position[2])
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(Pose(-0.30, 0.25, 0.15))  # go around the wall
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
