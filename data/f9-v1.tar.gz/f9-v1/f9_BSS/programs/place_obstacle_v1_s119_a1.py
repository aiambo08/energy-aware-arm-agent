try:
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.589, y=-0.179)
except SkillPreconditionFailed:
    dets = robot.detect("yellow")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("yellow")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.589, y=-0.179)
except (SkillPostconditionFailed, SkillFailed):
    d = None
    for det in robot.detect("yellow"):
        if det.complete:
            d = det
            break
    if d is None:
        d = next(iter(robot.detect("yellow")), None)
    if d is None:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        d = next(iter(robot.detect("yellow")), None)
    if d is not None:
        pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
        place = Pose(-0.589, -0.179, 0.0225, d.yaw_rad)
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
