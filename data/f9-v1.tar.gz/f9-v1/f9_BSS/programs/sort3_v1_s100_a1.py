robot.execute_skill("sort_cubes", 
                   color_1="green", x_1=-0.388, y_1=0.195,
                   color_2="yellow", x_2=-0.598, y_2=0.050,
                   color_3="blue", x_3=-0.644, y_3=-0.083)
