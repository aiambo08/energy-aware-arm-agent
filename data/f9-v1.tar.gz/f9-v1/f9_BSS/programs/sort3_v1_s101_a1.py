robot.execute_skill("sort_cubes", 
    color_1="green", x_1=-0.507, y_1=-0.119,
    color_2="red", x_2=-0.505, y_2=0.005,
    color_3="blue", x_3=-0.367, y_3=0.177)
