robot.execute_skill("sort_cubes", 
                   color_1="yellow", x_1=-0.537, y_1=0.018,
                   color_2="red", x_2=-0.635, y_2=0.157,
                   color_3="blue", x_3=-0.509, y_3=-0.149)
