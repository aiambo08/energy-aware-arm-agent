robot.execute_skill("sort_cubes", 
                   color_1="blue", x_1=-0.490, y_1=-0.148,
                   color_2="green", x_2=-0.577, y_2=-0.023,
                   color_3="red", x_3=-0.380, y_3=0.199)
