robot.execute_skill("sort_cubes", 
    color_1="yellow", x_1=-0.395, y_1=-0.008,
    color_2="blue", x_2=-0.573, y_2=-0.001,
    color_3="green", x_3=-0.642, y_3=-0.141)
