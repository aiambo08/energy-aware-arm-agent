robot.execute_skill("sort_cubes", 
    color_1="yellow", x_1=-0.428, y_1=-0.105,
    color_2="green", x_2=-0.646, y_2=0.149,
    color_3="red", x_3=-0.445, y_3=-0.005)
