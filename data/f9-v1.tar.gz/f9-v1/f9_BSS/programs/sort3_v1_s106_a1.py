robot.execute_skill("sort_cubes", 
    color_1="yellow", x_1=-0.650, y_1=0.039,
    color_2="green", x_2=-0.352, y_2=0.151,
    color_3="blue", x_3=-0.501, y_3=-0.083)
