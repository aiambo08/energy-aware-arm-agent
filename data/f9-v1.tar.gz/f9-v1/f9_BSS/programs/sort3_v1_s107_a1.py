robot.execute_skill("sort_cubes", 
    color_1="blue", x_1=-0.384, y_1=-0.035,
    color_2="red", x_2=-0.412, y_2=0.121,
    color_3="yellow", x_3=-0.489, y_3=0.198)
