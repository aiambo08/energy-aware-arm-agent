robot.execute_skill("sort_cubes", 
                   color_1="green", x_1=-0.472, y_1=0.014,
                   color_2="yellow", x_2=-0.546, y_2=0.134,
                   color_3="blue", x_3=-0.601, y_3=-0.098)
