robot.execute_skill("sort_cubes", 
                   color_1="green", x_1=-0.353, y_1=-0.006,
                   color_2="red", x_2=-0.636, y_2=-0.155,
                   color_3="yellow", x_3=-0.467, y_3=0.049)
