robot.execute_skill("sort_cubes", 
                   color_1="red", x_1=-0.540, y_1=0.188,
                   color_2="yellow", x_2=-0.398, y_2=-0.046,
                   color_3="green", x_3=-0.427, y_3=-0.166)
