robot.execute_skill("sort_cubes", 
    color_1="green", x_1=-0.578, y_1=0.070,
    color_2="yellow", x_2=-0.540, y_2=-0.042,
    color_3="red", x_3=-0.626, y_3=0.197)
