robot.execute_skill("stack_cube", top="blue", base="yellow")
