robot.execute_skill("stack_cube", top="green", base="yellow")
