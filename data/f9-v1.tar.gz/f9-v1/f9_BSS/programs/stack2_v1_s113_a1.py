robot.execute_skill("stack_cube", top="red", base="yellow")
