robot.execute_skill("stack_cube", top="yellow", base="red")
