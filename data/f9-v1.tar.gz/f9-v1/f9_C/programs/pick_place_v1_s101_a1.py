detections = robot.detect("red")
if not detections:
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    detections = robot.detect("red")

d = detections[0]
pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
target_xy = Pose(-0.487, 0.197, pick_pose.z)

approach_height = 0.10
lift_height = pick_pose.above(approach_height)
release_height = target_xy.above(0.005)

robot.move_to(lift_height)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(lift_height, 0.5)
robot.move_to(target_xy.above(approach_height))
robot.move_to(release_height, 0.5)
robot.release()
robot.move_to(target_xy.above(approach_height))
