detections = robot.detect("blue")
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("blue")

d = detections[0]
pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
place = Pose(-0.573, 0.046, pick.z)

robot.move_to(pick.above(0.10))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(0.10), 0.5)
robot.move_to(place.above(0.10))
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(0.10))
