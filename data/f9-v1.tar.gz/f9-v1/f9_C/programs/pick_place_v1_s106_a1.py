detections = robot.detect("yellow")
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("yellow")

d = detections[0]
pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
target_xy = Pose(-0.593, 0.021, pick.z)

approach_height = 0.10
lift_height = pick.above(approach_height)
place_height = target_xy.above(0.005)

robot.move_to(lift_height)
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(lift_height, 0.5)
robot.move_to(target_xy.above(approach_height))
robot.move_to(place_height, 0.5)
robot.release()
robot.move_to(target_xy.above(approach_height))
