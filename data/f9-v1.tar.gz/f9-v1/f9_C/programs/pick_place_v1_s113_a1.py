detections = robot.detect("red")
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("red")

d = detections[0]
pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
place_pose = Pose(-0.510, 0.172, pick_pose.z)

robot.move_to(pick_pose.above(0.10))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(0.10), 0.5)
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(0.10))
