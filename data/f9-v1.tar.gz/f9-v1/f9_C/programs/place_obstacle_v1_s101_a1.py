def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "blue")

# If blue cube not found or partially seen, move to observation pose on the side
if target is None or not target.complete:
    # Choose observation pose based on expected cube location or general coverage
    obs_pose = Pose(-0.30, -0.25, 0.15)  # Left side to avoid wall shadow
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "blue") or target

# If still not found, fail gracefully (but task states there are 3 cubes)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube resting on table
    place = Pose(-0.595, -0.111, place_z, target.yaw_rad)

    # Clearance height: avoid wall (10 cm high) and ensure safe travel
    # Wall is at x=-0.571, y=0.007, so approach from left (negative y) or back (more negative x)
    # We go to y=-0.111 (left of wall), so approach from left and behind
    lift_height = 0.12  # Just above wall height with margin

    # Move to pick position with safe clearance
    robot.move_to(pick.above(lift_height))
    robot.move_to(pick.above(0.015), 0.5)  # Slow descent for precision
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)  # Lift with margin over wall

    # Move to place position
    robot.move_to(place.above(lift_height))
    robot.move_to(place.above(0.005), 0.5)  # Final descent slow and precise
    robot.release()
    robot.move_to(place.above(lift_height))  # Lift after release
