def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or incomplete, move to observation pose
if target is None or not target.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, fail gracefully (but task states red exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # resting on table
    place = Pose(-0.548, 0.109, place_z, target.yaw_rad)
    
    # Clearance height: avoid wall and neighbours, keep low to save energy
    lift_height = 0.10
    
    # Move to pick position with clearance
    robot.move_to(pick.above(lift_height))
    robot.move_to(pick, 0.5)  # slower for precision
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)  # lift slowly
    
    # Move to place position with clearance (go high enough to clear wall: 10 cm)
    # But wall is at x=-0.571, y=-0.015, our path from pick to place may not need full 10cm
    # Since wall is behind and to the side, and we're moving to y=0.109, likely clear
    # Still, raise to 0.12 m to be safe
    robot.move_to(place.above(0.12))
    robot.move_to(place.above(0.005), 0.5)  # slow down for precise release
    robot.release()
    robot.move_to(place.above(0.12))
