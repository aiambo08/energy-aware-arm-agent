def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
target = find_cube(detections, "green")

# If green cube not found or partially seen, move to observation pose on the side
if target is None or not target.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)  # Side view to avoid arm shadow
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "green") or target  # Fallback to previous if still not found

# If still not found, fail gracefully (but task states green exists)
if target is None:
    robot.reset()
    raise PrimitiveError("code: NO_TARGET", "message: Green cube not detected")

# Define pick and place poses
pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
place_z = 0.0225  # Cube resting on table (half-height of cube)
place = Pose(-0.359, 0.177, place_z, target.yaw_rad)

# Clearance height: avoid wall and neighbours. Wall is 10 cm high, so clear at 0.12 m
clearance = 0.12

# Move to pick position with safe clearance
robot.move_to(pick.above(clearance))
robot.move_to(pick, 0.5)  # Slower for precision
robot.grasp()
robot.move_to(pick.above(clearance), 0.5)  # Lift slowly

# Move to place position (go around wall via higher path)
robot.move_to(place.above(clearance))
robot.move_to(place.above(0.005), 0.5)  # Lower slowly to release accurately
robot.release()
robot.move_to(place.above(clearance))  # Clear for safety
