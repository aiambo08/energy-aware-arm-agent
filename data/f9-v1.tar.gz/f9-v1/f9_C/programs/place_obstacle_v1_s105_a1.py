def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If yellow cube not found or incomplete, move to observation pose
if yellow is None or not yellow.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect("yellow")
    yellow = find_cube(detections, "yellow") or yellow

# If still not found, fail gracefully (but task states yellow exists)
if yellow is None:
    robot.reset()
    raise PrimitiveError("code": "NO_CUBE", "message": "Yellow cube not found")

# Define pick and place poses
pick = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
target_x = -0.566
target_y = 0.142
place_z = 0.0225  # resting on table
place = Pose(target_x, target_y, place_z, yellow.yaw_rad)

# Clearance height: avoid wall (10 cm high), add safety margin
clearance = 0.12

# Move to pick from above, grasp, lift
robot.move_to(pick.above(clearance))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(clearance), 0.5)

# Move to place via high arc to avoid wall
robot.move_to(place.above(clearance))
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(clearance))
