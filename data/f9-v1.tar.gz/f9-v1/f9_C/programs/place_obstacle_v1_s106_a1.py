def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or partial, move to observation pose
if target is None or not target.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, fail gracefully (but task states red exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place = Pose(-0.525, 0.181, pick.z, pick.yaw)

    # Approach from above with safe height (10 cm above cube)
    approach_height = 0.10
    lift_height = 0.10

    # Move to pick position (from above, slower for precision)
    robot.move_to(pick.above(approach_height))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)

    # Move to place position (avoiding wall by going higher if needed)
    # Wall is at x=-0.591, y=0.008, so path from current x~ -0.3 to -0.525 may pass near wall
    # To avoid, we lift higher if necessary. Since wall is 10 cm high, we clear with z >= 0.12
    # But our lift_height is already 0.10, and cube z is ~0.0225, so TCP at ~0.1225 — safe
    # However, to be safe from wall, we go slightly higher: 0.15 m above pick z
    safe_height = 0.15
    robot.move_to(place.above(safe_height))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(safe_height))
