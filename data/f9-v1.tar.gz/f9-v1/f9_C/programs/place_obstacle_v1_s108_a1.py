def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

# Initial detection
detections = robot.detect("green")
green = find_cube(detections, "green")

# If green cube not found or partially visible, move to observation pose
if green is None or not green.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)  # Clear view from northeast
    robot.move_to(obs_pose)
    detections = robot.detect("green")
    green = find_cube(detections, "green") or green

# If still not found, fail gracefully (but task states there is a green cube)
if green is None:
    robot.reset()
    raise PrimitiveError("NoObjectGrasped", "Green cube not found")

# Define pick and place poses
pick = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
target_xy = Pose(-0.394, 0.076, pick.z)
clearance_z = 0.12  # High enough to clear the 10 cm wall with margin

# Move above pick with high clearance to avoid wall
robot.move_to(pick.above(clearance_z))
robot.move_to(pick, 0.5)  # Slow for precision
robot.grasp()
robot.move_to(pick.above(clearance_z), 0.5)  # Lift slowly for stability

# Move to above target with high clearance to avoid wall
robot.move_to(target_xy.above(clearance_z))
robot.move_to(target_xy.above(0.005), 0.5)  # Slow descent to place gently
robot.release()

# Lift slightly after release
robot.move_to(target_xy.above(clearance_z))
