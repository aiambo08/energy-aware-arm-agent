def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

# First attempt to detect blue cube from ready pose
detections = robot.detect()
blue = find_cube(detections, "blue")

# If blue cube not found or top face not fully visible, move to observation pose
if blue is None or not blue.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue

# If still not found, fail gracefully (but task states blue exists)
if blue is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
    place_z = 0.0225  # Cube resting on table
    place = Pose(-0.596, -0.114, place_z, blue.yaw_rad)

    # Clearance height: avoid wall and other cubes
    lift_height = 0.10

    # Move to pick position with clearance
    robot.move_to(pick.above(lift_height))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)
    
    # Move to place position with higher clearance to avoid wall
    # Wall is at x=-0.490, so we pass it at higher z
    robot.move_to(place.above(0.15))  # Higher over wall
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.15))
