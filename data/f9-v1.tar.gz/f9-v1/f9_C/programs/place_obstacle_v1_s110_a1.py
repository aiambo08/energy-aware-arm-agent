def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or partially visible, move to observation pose
if target is None or not target.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)  # Clear view for left side
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, fail gracefully (but task states red exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Resting height on table
    place = Pose(-0.497, -0.158, place_z, target.yaw_rad)

    # Clearance height: just enough to avoid wall (10 cm) and cubes, add safety margin
    lift_height = 0.12

    # Move to pick position with safe clearance
    robot.move_to(pick.above(lift_height))
    robot.move_to(pick, 0.5)  # Slower for precision
    robot.grasp()
    robot.move_to(pick.above(lift_height), 0.5)  # Lift slowly

    # Move to place position
    robot.move_to(place.above(lift_height))
    robot.move_to(place.above(0.005), 0.5)  # Descend slowly
    robot.release()
    robot.move_to(place.above(lift_height))
