def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or partially visible, move to observation pose
if target is None or not target.complete:
    obs_pose = Pose(-0.30, 0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, fail gracefully (but task guarantees it exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place = Pose(-0.376, 0.126, pick.z, pick.yaw)

    # Lift height: just enough to clear neighbours and wall (10 cm wall, so 12 cm clearance)
    lift_z = 0.12 + pick.z

    # Move to pick position with safe height
    robot.move_to(pick.above(lift_z))
    # Descend slowly for precision
    robot.move_to(pick, 0.5)
    robot.grasp()
    # Lift slowly to avoid swing
    robot.move_to(pick.above(lift_z), 0.5)
    # Move to place location (avoiding wall via high arc)
    robot.move_to(place.above(lift_z))
    # Descend slowly to place
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    # Lift slightly after release
    robot.move_to(place.above(0.02))
