def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect("blue")
blue = find_cube(detections, "blue")

# If blue cube not found or incomplete, move to observation pose
if blue is None or not blue.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)
    robot.move_to(obs_pose)
    detections = robot.detect("blue")
    blue = find_cube(detections, "blue") or blue  # Fallback to previous if still not found

# Define pick and place poses
pick_pose = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
target_x = -0.529
target_y = -0.172
place_z = 0.0225  # Resting height of cube centre on table
place_pose = Pose(target_x, target_y, place_z, blue.yaw_rad)

# Approach from 10 cm above for safety
approach_height = 0.10
clearance = 0.06  # Extra lift to clear potential neighbours

# Move to pick
robot.move_to(pick_pose.above(approach_height))
robot.move_to(pick_pose.above(clearance), 0.5)
robot.grasp()
robot.move_to(pick_pose.above(approach_height), 0.5)

# Move to place (go via higher path to avoid wall)
robot.move_to(place_pose.above(0.15))  # High arc to clear wall
robot.move_to(place_pose.above(0.005), 0.5)  # Final descent with precision
robot.release()
robot.move_to(place_pose.above(0.15))
