detections = robot.detect("blue")
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect("blue")

d = detections[0]
pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
place = Pose(-0.354, -0.004, pick.z)

# Approach from higher to clear wall (10 cm) and cube stack
lift_height = 0.12

robot.move_to(pick.above(lift_height))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(lift_height), 0.5)
robot.move_to(place.above(lift_height))
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(lift_height))
