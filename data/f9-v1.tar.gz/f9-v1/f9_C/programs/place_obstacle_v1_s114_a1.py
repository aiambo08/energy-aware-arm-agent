def find_cube(color):
    dets = robot.detect(target=color)
    if not dets:
        # Move to observation pose to improve detection
        obs_pose = Pose(-0.30, -0.25, 0.15)
        robot.move_to(obs_pose)
        dets = robot.detect(target=color)
    return dets[0] if dets else None

# Find yellow cube
yellow = find_cube("yellow")
if yellow is None:
    # Fallback: full detection if color not found
    all_dets = robot.detect()
    yellow = next((d for d in all_dets if d.color == "yellow"), None)
    if yellow is None:
        raise PrimitiveError("No yellow cube detected")

# Define pick and place poses
pick = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
target_z = 0.0225  # resting height of cube centre
place = Pose(-0.374, -0.081, target_z, yellow.yaw_rad)

# Clearance height: avoid wall and cubes, use minimal safe height
clearance = 0.10

# Move to pick
robot.move_to(pick.above(clearance))
robot.move_to(pick, 0.5)
robot.grasp()
# Lift
robot.move_to(pick.above(clearance), 0.5)

# Move to place (go via higher path to avoid wall)
# Wall is at x=-0.498, so we pass x > -0.45 safely
via = Pose(-0.40, -0.081, 0.15)
robot.move_to(via)
robot.move_to(place.above(clearance))
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(clearance))
