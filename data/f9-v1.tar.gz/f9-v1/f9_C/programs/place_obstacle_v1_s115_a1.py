def find_cube(color, dets):
    for d in dets:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube("green", detections)

# If green cube not found or partial, move to observation pose on the side
if target is None or not target.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)  # Clear view from bottom-left edge
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube("green", detections) or target

# If still not found, fail gracefully (but task states green exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube centre when resting on table
    place = Pose(-0.365, -0.199, place_z, target.yaw_rad)

    # Clearance height: avoid wall and neighbours; 10 cm clearance should be safe
    lift_height = 0.10

    # Move to pick position with high clearance
    robot.move_to(pick.above(lift_height))
    # Descend slowly for precision
    robot.move_to(pick, 0.5)
    robot.grasp()
    # Lift slowly after grasp
    robot.move_to(pick.above(lift_height), 0.5)
    # Move to place location
    robot.move_to(place.above(lift_height))
    # Descend to just above table for release
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    # Lift slightly after release
    robot.move_to(place.above(lift_height))
