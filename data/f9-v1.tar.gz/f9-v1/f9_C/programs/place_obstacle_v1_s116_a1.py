def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection from ready pose
detections = robot.detect()
target = find_cube(detections, "red")

# If red cube not found or partially visible, move to observation pose
if target is None or not target.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)  # Clear view of lower-left area
    robot.move_to(obs_pose)
    detections = robot.detect()
    target = find_cube(detections, "red") or target

# If still not found, fail gracefully (but task guarantees it exists)
if target is None:
    robot.reset()
else:
    # Define pick and place poses
    pick = Pose(target.position[0], target.position[1], target.position[2], target.yaw_rad)
    place_z = 0.0225  # Cube centre when resting on table
    place = Pose(-0.401, -0.195, place_z, target.yaw_rad)

    # Clearance height: just enough to avoid wall (10 cm) and other cubes
    # Lift to 12 cm above table (z=0.12) for safe travel
    lift_height = 0.12

    # Approach from above with safe clearance
    try:
        robot.move_to(pick.above(lift_height))
        robot.move_to(pick, 0.5)  # Slower for precision
        robot.grasp()
        robot.move_to(pick.above(lift_height), 0.5)
        
        # Move to place location
        robot.move_to(place.above(lift_height))
        robot.move_to(place.above(0.005), 0.5)  # Final descent slow
        robot.release()
        robot.move_to(place.above(lift_height))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        # In case of error, return to safe pose
        robot.reset()
