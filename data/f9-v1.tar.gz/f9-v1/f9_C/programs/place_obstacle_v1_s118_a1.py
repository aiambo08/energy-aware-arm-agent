def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
yellow = find_cube(detections, "yellow")

# If yellow cube not found or partial, move to observation pose that avoids arm shadow
if yellow is None or not yellow.complete:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs in obs_poses:
        try:
            robot.move_to(obs, speed_scale=0.8)
            detections = robot.detect()
            yellow = find_cube(detections, "yellow")
            if yellow is not None and yellow.complete:
                break
        except (OutOfReach, Singularity, Collision):
            continue

# If still not found, use last detection (best effort)
if yellow is None:
    detections = robot.detect()
    yellow = find_cube(detections, "yellow")
    if yellow is None:
        # Cannot proceed without detecting yellow cube
        robot.reset()
        raise PrimitiveError("code": "NO_DETECTION", "message": "Yellow cube not detected")

# Define pick and place poses
pick = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
target_z = 0.0225  # resting height of cube centre on table
place = Pose(-0.613, 0.156, target_z, yellow.yaw_rad)

# Clearance height: avoid wall (10 cm high) and ensure safe travel
clearance = 0.12  # 12 cm above table (above wall height)

# Move to pick position with safe clearance
approach_pick = pick.above(clearance)
robot.move_to(approach_pick, speed_scale=0.8)

# Descend slowly for precision
robot.move_to(pick, speed_scale=0.5)
robot.grasp()

# Lift with clearance
lifted = pick.above(clearance)
robot.move_to(lifted, speed_scale=0.8)

# Move to place location (avoid wall and other cubes)
approach_place = place.above(clearance)
robot.move_to(approach_place, speed_scale=0.8)

# Final descent with precision
robot.move_to(place.above(0.005), speed_scale=0.5)
robot.release()

# Lift slightly after release
robot.move_to(place.above(clearance), speed_scale=0.8)
