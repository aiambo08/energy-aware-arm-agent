def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

# Initial detection from ready pose
detections = robot.detect("yellow")
yellow = find_cube(detections, "yellow")

# If yellow cube not found or incomplete, move to observation pose on the side
if yellow is None or not yellow.complete:
    obs_pose = Pose(-0.30, -0.25, 0.15)  # Clear view from bottom-left corner
    robot.move_to(obs_pose)
    detections = robot.detect("yellow")
    yellow = find_cube(detections, "yellow") or yellow  # Fallback to previous if still not found

# If still not found, fail gracefully (but task states there are 3 cubes including yellow)
if yellow is None:
    robot.reset()
    raise PrimitiveError("code: NO_CUBES", "message: Yellow cube not detected")

# Define pick and place poses
pick = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
target_xy = Pose(-0.589, -0.179, pick.z)  # Target at same height as cube

# Clearance height: just enough to clear neighbours and wall (10 cm wall, so 12 cm clearance)
clearance_z = 0.12 + pick.z

# Approach from above with safe height
robot.move_to(pick.above(clearance_z))
robot.move_to(pick, 0.5)  # Slow for precision
robot.grasp()
robot.move_to(pick.above(clearance_z), 0.5)  # Lift slowly

# Move to target with arc over the wall (go higher only if needed; wall is 10 cm)
# Since wall is at x=-0.505, y=-0.019, and we're going from current to (-0.589, -0.179),
# the path passes near the wall, so use clearance_z which is above 10 cm
robot.move_to(target_xy.above(clearance_z))
robot.move_to(target_xy.above(0.005), 0.5)  # Final descent slow
robot.release()
robot.move_to(target_xy.above(clearance_z))  # Lift slowly after release
