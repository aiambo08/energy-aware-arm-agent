def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    return None

# Target positions for each color
targets = {
    "green": Pose(-0.388, 0.195, 0.0225),
    "yellow": Pose(-0.598, 0.050, 0.0225),
    "blue": Pose(-0.644, -0.083, 0.0225)
}

# Detect all cubes initially
detections = robot.detect()

# For each color, move to target position if not already there
for color, target_pose in targets.items():
    # Find current detection of this color
    d = next((det for det in detections if det.color == color), None)
    if d is None:
        # Try from observation pose to improve detection
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        d = get_detection(color)
        if d is None:
            continue  # Skip if still not found

    # Create pick pose at cube center with correct yaw
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    
    # Check if cube is already near its target (within 2 cm in xy)
    if pick_pose.distance_xy(target_pose) < 0.02:
        continue  # Already in place
    
    # Approach from 10 cm above
    approach_height = 0.10
    release_height = 0.005
    
    # Move to pick position
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(approach_height), 0.5)
    
    # Move to target and release
    robot.move_to(target_pose.above(approach_height))
    robot.move_to(target_pose.above(release_height), 0.5)
    robot.release()
    robot.move_to(target_pose.above(approach_height))
