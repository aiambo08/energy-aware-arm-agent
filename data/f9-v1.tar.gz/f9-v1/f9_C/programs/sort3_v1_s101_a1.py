def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    return None

def move_and_detect(target):
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect()
    for d in dets:
        if d.color == target:
            return d
    robot.move_to(Pose(-0.30, 0.25, 0.15))
    dets = robot.detect()
    for d in dets:
        if d.color == target:
            return d
    robot.move_to(Pose(-0.30, -0.25, 0.15))
    dets = robot.detect()
    for d in dets:
        if d.color == target:
            return d
    return None

targets = {
    "green": Pose(-0.507, -0.119, 0.0225),
    "red": Pose(-0.505, 0.005, 0.0225),
    "blue": Pose(-0.367, 0.177, 0.0225)
}

for color, place_pose in targets.items():
    d = get_detection(color)
    if d is None or not d.complete:
        d = move_and_detect(color)
    if d is None:
        continue
    
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    approach_height = 0.10
    lift_height = pick_pose.z + approach_height
    release_height = place_pose.z + 0.005
    
    try:
        robot.move_to(pick_pose.above(lift_height))
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(lift_height), 0.5)
        robot.move_to(place_pose.above(lift_height))
        robot.move_to(place_pose.above(release_height), 0.5)
        robot.release()
        robot.move_to(place_pose.above(lift_height))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        pass

robot.move_to(Pose(-0.50, 0.0, 0.25))
