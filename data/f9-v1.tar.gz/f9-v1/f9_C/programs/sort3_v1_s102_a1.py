# Define target positions for each color
targets = {
    "yellow": Pose(-0.537, 0.018, 0.0225),
    "red": Pose(-0.635, 0.157, 0.0225),
    "blue": Pose(-0.509, -0.149, 0.0225)
}

# Function to get best detection (complete first, otherwise any)
def get_best_detection(dets, color):
    hits = [d for d in dets if d.color == color]
    full = [d for d in hits if d.complete]
    return (full or hits)[0] if hits else None

# Detect all cubes initially
detections = robot.detect()

# For each color, move to target location
for color, target_pose in targets.items():
    # Find the cube of this color
    d = get_best_detection(detections, color)
    
    # If not found or incomplete, move to observation pose to improve detection
    if d is None or not d.complete:
        obs_pose = Pose(-0.30, 0.0, 0.15)
        try:
            robot.move_to(obs_pose, 0.7)
        except (OutOfReach, Singularity, Collision):
            pass  # Continue with existing detections if move fails
        detections = robot.detect()
        d = get_best_detection(detections, color) or d  # Use best available
    
    if d is None:
        continue  # Skip if still not found
    
    # Create pick pose from detection
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    
    # Approach from 10 cm above, descend slowly, grasp, lift
    approach_height = 0.10
    lift_height = 0.10
    release_clearance = 0.005
    
    try:
        robot.move_to(pick_pose.above(approach_height), 0.7)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(lift_height), 0.7)
        
        # Move to target location
        robot.move_to(target_pose.above(lift_height), 0.7)
        robot.move_to(target_pose.above(release_clearance), 0.5)
        robot.release()
        robot.move_to(target_pose.above(lift_height), 0.7)
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        # If something goes wrong, continue with next cube
        continue

# Return to ready pose to finish cleanly
robot.move_to(Pose(-0.50, 0.0, 0.25), 0.7)
