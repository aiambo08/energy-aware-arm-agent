def get_detections(target="any"):
    return robot.detect(target)

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_with_retry(pose, speed_scale=1.0):
    try:
        robot.move_to(pose, speed_scale)
    except (OutOfReach, Singularity, Collision):
        if pose.z < 0.10:
            robot.move_to(pose.above(0.10))
        robot.move_to(pose, speed_scale)

def grasp_cube(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick.above(0.10)
    pregrasp = pick.above(0.005)
    move_with_retry(approach)
    move_with_retry(pregrasp, 0.5)
    robot.grasp()
    move_with_retry(approach, 0.5)
    return pick

def place_cube(target_pose):
    approach = target_pose.above(0.10)
    preplace = target_pose.above(0.005)
    move_with_retry(approach)
    move_with_retry(preplace, 0.5)
    robot.release()
    move_with_retry(approach, 0.5)

# Target positions
targets = {
    "blue": Pose(-0.490, -0.148, 0.0225),
    "green": Pose(-0.577, -0.023, 0.0225),
    "red": Pose(-0.380, 0.199, 0.0225)
}

# Initial detection
detections = get_detections()
observed_colors = {d.color for d in detections}

# If any target cube is missing or incomplete, move to observation pose
if len(observed_colors) < 3 or not all(d.complete for d in detections):
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        robot.move_to(obs_pose)
        detections = get_detections()
        observed_colors = {d.color for d in detections}
        if len(observed_colors) == 3 and all(d.complete for d in detections):
            break

# Sort cubes by moving each to its target
for color, target_pose in targets.items():
    d = find_cube(detections, color)
    if d is not None:
        pick_pose = grasp_cube(d)
        place_cube(target_pose)
