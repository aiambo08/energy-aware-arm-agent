targets = {
    "yellow": Pose(-0.395, -0.008, 0.0225),
    "blue": Pose(-0.573, -0.001, 0.0225),
    "green": Pose(-0.642, -0.141, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

def approach_grasp_release(pick_pose, place_pose):
    approach_pick = pick_pose.above(0.10)
    lift_pick = pick_pose.above(0.10)
    approach_place = place_pose.above(0.10)
    release_place = place_pose.above(0.005)
    
    robot.move_to(approach_pick)
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(lift_pick, 0.5)
    robot.move_to(approach_place)
    robot.move_to(release_place, 0.5)
    robot.release()
    robot.move_to(approach_place)

detections = get_detections()
observed = {d.color: d for d in detections}

missing_colors = set(targets.keys()) - set(observed.keys())
if missing_colors:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = get_detections()
    for d in detections:
        observed[d.color] = d

for color, target_pose in targets.items():
    if color not in observed:
        continue
    d = observed[color]
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    approach_grasp_release(pick_pose, target_pose)
