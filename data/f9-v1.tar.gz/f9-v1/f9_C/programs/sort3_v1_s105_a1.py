def get_detection(target):
    dets = robot.detect(target)
    if dets:
        return dets[0]
    return None

def move_and_detect(target):
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for p in obs_poses:
        try:
            robot.move_to(p, 0.8)
            d = get_detection(target)
            if d:
                return d
        except:
            continue
    return get_detection(target)

targets = {
    "yellow": Pose(-0.428, -0.105, 0.0225),
    "green": Pose(-0.646, 0.149, 0.0225),
    "red": Pose(-0.445, -0.005, 0.0225)
}

robot.move_to(Pose(-0.30, 0.0, 0.15), 0.8)
detections = robot.detect()

for color, target_pose in targets.items():
    d = next((det for det in detections if det.color == color), None)
    if d is None or not d.complete:
        d = move_and_detect(color)
        if d is None:
            continue
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    approach_height = 0.10
    if d.depth_m < 0.5:
        approach_height = max(0.06, d.depth_m * 0.1)
    try:
        robot.move_to(pick_pose.above(approach_height), 0.8)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(approach_height), 0.8)
        robot.move_to(target_pose.above(approach_height), 0.8)
        robot.move_to(target_pose.above(0.005), 0.5)
        robot.release()
        robot.move_to(target_pose.above(approach_height), 0.8)
    except:
        try:
            robot.move_to(Pose(-0.50, 0.0, 0.25), 0.8)
        except:
            pass
robot.reset()
