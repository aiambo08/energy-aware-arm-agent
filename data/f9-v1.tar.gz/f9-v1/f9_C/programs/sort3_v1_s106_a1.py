def get_detections(target="any"):
    return robot.detect(target)

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_with_retry(pose, speed_scale=1.0):
    try:
        robot.move_to(pose, speed_scale)
    except (OutOfReach, Singularity, Collision):
        raise
    except Timeout:
        robot.move_to(pose, speed_scale)

def grasp_with_check():
    robot.grasp()

def place_cube(target_pos):
    place_pose = Pose(target_pos[0], target_pos[1], 0.0225, 0.0)
    robot.move_to(place_pose.above(0.10))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(0.10))

# Target positions
targets = {
    "yellow": (-0.650, 0.039),
    "green": (-0.352, 0.151),
    "blue": (-0.501, -0.083)
}

# Initial detection
detections = get_detections()

# If any target cube is missing or incomplete, move to observation pose
missing_or_partial = False
for color in targets:
    cube = find_cube(detections, color)
    if cube is None or not cube.complete:
        missing_or_partial = True
        break

if missing_or_partial:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        move_with_retry(obs_pose, 0.8)
        new_dets = get_detections()
        for d in new_dets:
            existing = find_cube(detections, d.color)
            if existing is None or not existing.complete:
                detections = [det for det in detections if det.color != d.color] + [d]
        # Check if all needed cubes are now complete
        complete = all(find_cube(detections, c) and find_cube(detections, c).complete for c in targets)
        if complete:
            break

# Sort cubes by color
for color, target_pos in targets.items():
    cube = find_cube(detections, color)
    if cube is None:
        continue
    
    # Pick pose
    pick_pose = Pose(cube.position[0], cube.position[1], cube.position[2], cube.yaw_rad)
    
    # Approach from above with clearance
    approach_height = 0.10
    # Check if any other cube is nearby that might collide during lift
    for other in detections:
        if other.color != color:
            dx = abs(other.position[0] - cube.position[0])
            dy = abs(other.position[1] - cube.position[1])
            if dx < 0.12 and dy < 0.12:
                approach_height = max(approach_height, 0.15)
    
    # Move to pick
    move_with_retry(pick_pose.above(approach_height))
    move_with_retry(pick_pose, 0.5)
    grasp_with_check()
    move_with_retry(pick_pose.above(approach_height), 0.5)
    
    # Place at target
    place_cube(target_pos)
