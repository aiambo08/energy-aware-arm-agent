targets = {
    "blue": Pose(-0.384, -0.035, 0.0225),
    "red": Pose(-0.412, 0.121, 0.0225),
    "yellow": Pose(-0.489, 0.198, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    matches = [d for d in dets if d.color == color]
    complete_matches = [d for d in matches if d.complete]
    return complete_matches[0] if complete_matches else (matches[0] if matches else None)

def approach_grasp_release(pick_pose, place_pose):
    approach_pick = pick_pose.above(0.10)
    lift_pick = pick_pose.above(0.10)
    approach_place = place_pose.above(0.10)
    release_place = place_pose.above(0.005)
    
    robot.move_to(approach_pick)
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(lift_pick, 0.5)
    robot.move_to(approach_place)
    robot.move_to(release_place, 0.5)
    robot.release()
    robot.move_to(approach_place)

detections = get_detections()
observed_colors = {d.color for d in detections}

missing_colors = set(targets.keys()) - observed_colors
if missing_colors:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = get_detections()

for color in ["blue", "red", "yellow"]:
    d = find_cube(detections, color)
    if d is None:
        continue
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = targets[color]
    approach_grasp_release(pick, place)
