targets = {
    "blue": Pose(-0.541, 0.167, 0.0225),
    "red": Pose(-0.352, -0.108, 0.0225),
    "green": Pose(-0.628, 0.019, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    matches = [d for d in dets if d.color == color]
    complete_matches = [d for d in matches if d.complete]
    return complete_matches[0] if complete_matches else (matches[0] if matches else None)

def move_and_grasp(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick.above(0.10)
    lift = pick.above(0.10)
    robot.move_to(approach)
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(lift, 0.5)
    return pick

def place_at(pick_pose, target_pose):
    release_height = target_pose.z + 0.005
    robot.move_to(target_pose.above(0.10))
    robot.move_to(target_pose.with_yaw(pick_pose.yaw), 0.5)
    robot.move_to(target_pose.with_yaw(pick_pose.yaw).above(release_height), 0.5)
    robot.release()
    robot.move_to(target_pose.above(0.10))

detections = get_detections()
if not detections:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = get_detections()

for color, target in targets.items():
    cube = find_cube(detections, color)
    if cube:
        pick_pose = move_and_grasp(cube)
        place_at(pick_pose, target)
        detections = [d for d in detections if d.color != color]
