# Define target positions for each color
targets = {
    "green": Pose(-0.472, 0.014, 0.0225),
    "yellow": Pose(-0.546, 0.134, 0.0225),
    "blue": Pose(-0.601, -0.098, 0.0225)
}

# Detect all cubes
detections = robot.detect()

# Create a list of cubes to process: each has color, current pose, target pose
cubes = []
for d in detections:
    if d.color in targets:
        current = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
        target = targets[d.color].with_yaw(d.yaw_rad)
        cubes.append({"color": d.color, "current": current, "target": target})

# Sort cubes by y-distance to target to prioritize distant ones (minimize arm travel)
# We'll process one by one
for cube in cubes:
    color = cube["color"]
    pick = cube["current"]
    place = cube["target"]

    # Approach from 10 cm above to avoid collision
    approach_height = 0.10
    lift_height = pick.above(approach_height)
    place_lift = place.above(approach_height)

    try:
        # Move to approach position above current cube
        robot.move_to(lift_height, speed_scale=1.0)
        # Descend slowly for precision
        robot.move_to(pick, speed_scale=0.5)
        robot.grasp()
        # Lift back up
        robot.move_to(lift_height, speed_scale=0.5)
        # Move to target location
        robot.move_to(place_lift, speed_scale=1.0)
        # Descend to just above resting height
        robot.move_to(place.above(0.005), speed_scale=0.5)
        robot.release()
        # Lift slightly to clear
        robot.move_to(place_lift, speed_scale=0.5)
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        # If any error occurs, continue with next cube if possible
        continue

# Final move to safe position
robot.move_to(Pose(-0.50, 0.0, 0.25))
