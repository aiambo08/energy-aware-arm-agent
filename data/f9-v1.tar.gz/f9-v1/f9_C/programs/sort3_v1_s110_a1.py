targets = {
    "green": Pose(-0.536, -0.145, 0.0225),
    "blue": Pose(-0.354, -0.025, 0.0225),
    "red": Pose(-0.370, 0.133, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

def move_and_grasp(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick.above(0.10)
    pre_grasp = pick.above(0.015)
    robot.move_to(approach)
    robot.move_to(pre_grasp, 0.5)
    robot.grasp()
    robot.move_to(approach, 0.5)

def move_and_place(place_pose):
    approach = place_pose.above(0.10)
    release_height = place_pose.above(0.005)
    robot.move_to(approach)
    robot.move_to(release_height, 0.5)
    robot.release()
    robot.move_to(approach, 0.5)

detections = get_detections()
colors = ["red", "blue", "green"]

for color in colors:
    target_pose = targets[color]
    cube = find_cube(detections, color)
    if cube is None:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        detections = get_detections()
        cube = find_cube(detections, color)
        if cube is None:
            continue
    if abs(cube.position[0] - target_pose.x) < 0.01 and abs(cube.position[1] - target_pose.y) < 0.01:
        continue
    move_and_grasp(cube)
    move_and_place(target_pose)
