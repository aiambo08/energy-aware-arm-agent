targets = {
    "green": Pose(-0.475, 0.018, 0.0225),
    "yellow": Pose(-0.388, 0.126, 0.0225),
    "blue": Pose(-0.641, 0.102, 0.0225)
}

detections = robot.detect("any")

# Map color to current best detection
current = {d.color: d for d in detections if d.color in targets}

# For each color that's not already at its target, plan pick and place
for color in targets:
    if color not in current:
        # Try observing from a better angle if not seen
        obs_pose = Pose(-0.30, 0.0, 0.15)
        robot.move_to(obs_pose)
        detections = robot.detect(color)
        current_det = next((d for d in detections if d.color == color), None)
        if current_det is None:
            continue  # Skip if still not found
        current[color] = current_det

    d = current[color]
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = targets[color]

    # Approach from above with clearance
    approach_height = 0.10
    lift_height = 0.10

    # Only move if not already near target
    if pick.distance_xy(place) > 0.02:
        try:
            robot.move_to(pick.above(approach_height))
            robot.move_to(pick, 0.5)
            robot.grasp()
            robot.move_to(pick.above(lift_height), 0.5)
            robot.move_to(place.above(lift_height))
            robot.move_to(place.above(0.005), 0.5)
            robot.release()
            robot.move_to(place.above(lift_height))
        except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
            pass  # If any error, just continue to next cube
