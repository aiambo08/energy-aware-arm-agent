targets = {
    "green": Pose(-0.353, -0.006, 0.0225),
    "red": Pose(-0.636, -0.155, 0.0225),
    "yellow": Pose(-0.467, 0.049, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

def move_and_grasp(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick.above(0.10)
    lift = pick.above(0.10)
    robot.move_to(approach)
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(lift, 0.5)
    return pick

def place_cube(target_pose):
    approach = target_pose.above(0.10)
    release_height = target_pose.above(0.005)
    robot.move_to(approach)
    robot.move_to(release_height, 0.5)
    robot.release()
    robot.move_to(approach)

detections = get_detections()
observed_colors = {d.color for d in detections}
missing_colors = set(targets.keys()) - observed_colors

if missing_colors:
    obs_poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
    for obs_pose in obs_poses:
        robot.move_to(obs_pose)
        new_dets = get_detections()
        for d in new_dets:
            if d.color in missing_colors and not any(prev.color == d.color for prev in detections):
                detections.append(d)
                missing_colors.remove(d.color)
        if not missing_colors:
            break

for color in ["red", "green", "yellow"]:
    target_pose = targets[color]
    cube = find_cube(detections, color)
    if cube:
        pick_pose = move_and_grasp(cube)
        place_cube(target_pose)
