targets = {
    "red": (-0.537, 0.086),
    "yellow": (-0.364, -0.166),
    "blue": (-0.390, -0.021)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

def move_and_detect_if_needed():
    dets = get_detections()
    missing_colors = [c for c in targets.keys() if find_cube(dets, c) is None]
    if missing_colors:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = get_detections()
    return dets

dets = move_and_detect_if_needed()

for color, (tx, ty) in targets.items():
    d = find_cube(dets, color)
    if d is None:
        continue
        
    current_z = d.position[2]
    pick_pose = Pose(d.position[0], d.position[1], current_z, d.yaw_rad)
    place_pose = Pose(tx, ty, current_z).with_yaw(pick_pose.yaw)

    approach_height = 0.10
    lift_height = 0.05
    release_height = 0.005

    try:
        robot.move_to(pick_pose.above(approach_height))
        robot.move_to(pick_pose.above(lift_height), 0.5)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(pick_pose.above(lift_height), 0.5)
        robot.move_to(place_pose.above(lift_height))
        robot.move_to(place_pose.above(release_height), 0.5)
        robot.release()
        robot.move_to(place_pose.above(lift_height))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        continue
