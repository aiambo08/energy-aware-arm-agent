def get_detections(target="any"):
    return robot.detect(target)

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_and_grasp(detection):
    pick_pose = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick_pose.above(0.10)
    pre_grasp = pick_pose.above(0.015)
    robot.move_to(approach, 1.0)
    robot.move_to(pre_grasp, 0.5)
    robot.grasp()
    robot.move_to(approach, 0.5)

def move_and_place(pick_pose, place_position):
    place_pose = Pose(place_position[0], place_position[1], pick_pose.z, pick_pose.yaw)
    approach = place_pose.above(0.10)
    pre_place = place_pose.above(0.005)
    robot.move_to(approach, 1.0)
    robot.move_to(pre_place, 0.5)
    robot.release()
    robot.move_to(approach, 0.5)

targets = {
    "blue": (-0.616, -0.147),
    "yellow": (-0.496, -0.102),
    "red": (-0.362, 0.176)
}

# Initial detection
detections = get_detections()
if len(detections) < 3:
    # Move to observation pose to improve detection
    robot.move_to(Pose(-0.30, 0.0, 0.15), 1.0)
    detections = get_detections()

# Process each target color
for color, target_pos in targets.items():
    cube = find_cube(detections, color)
    if cube is None:
        continue
    
    # Grasp the cube
    pick_pose = Pose(cube.position[0], cube.position[1], cube.position[2], cube.yaw_rad)
    move_and_grasp(cube)
    
    # Place at target
    move_and_place(pick_pose, target_pos)

# Return to ready pose
robot.move_to(Pose(-0.50, 0.0, 0.25), 1.0)
