def get_target_position(color):
    targets = {
        "red": (-0.487, -0.154),
        "green": (-0.565, 0.185),
        "blue": (-0.617, 0.077)
    }
    return targets.get(color)

def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

def move_and_grasp(detection):
    pick = Pose(detection.position[0], detection.position[1], detection.position[2], detection.yaw_rad)
    approach = pick.above(0.10)
    lift = pick.above(0.10)
    robot.move_to(approach)
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(lift, 0.5)

def place_cube(target_pos, z, yaw):
    place = Pose(target_pos[0], target_pos[1], z, yaw)
    approach = place.above(0.10)
    release_height = place.above(0.005)
    robot.move_to(approach)
    robot.move_to(release_height, 0.5)
    robot.release()
    robot.move_to(approach)

# Initial detection
detections = robot.detect()

# Define observation pose to avoid arm shadow
obs_pose = Pose(-0.30, 0.0, 0.15)

# List of required colors
colors = ["red", "green", "blue"]
cubes_to_move = []

# Check for all cubes, re-observe if any is missing
for color in colors:
    d = find_cube(detections, color)
    if d is None or not d.complete:
        robot.move_to(obs_pose)
        new_dets = robot.detect()
        d = find_cube(new_dets, color) or d  # fallback to incomplete if still missing
    if d:
        cubes_to_move.append((d, get_target_position(color)))

# Sort cubes by distance from their targets to minimize travel? Not necessary here.
# Just process each cube
for detection, target_pos in cubes_to_move:
    if detection is None or target_pos is None:
        continue
    move_and_grasp(detection)
    place_cube(target_pos, 0.0225, detection.yaw_rad)
