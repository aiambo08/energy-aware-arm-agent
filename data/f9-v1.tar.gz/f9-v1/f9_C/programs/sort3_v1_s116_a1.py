# Define target positions for each color
targets = {
    "red": (-0.540, 0.188),
    "yellow": (-0.398, -0.046),
    "green": (-0.427, -0.166)
}

# Observation pose to avoid arm shadow
observe_pose = Pose(-0.30, 0.0, 0.15)

# Initial detection
detections = robot.detect()

# Helper: get best detection for a color (prefer complete)
def get_cube(dets, color):
    hits = [d for d in dets if d.color == color]
    full = [d for d in hits if d.complete]
    return (full or hits)[0] if hits else None

# For each color, move cube to its target
for color, (tx, ty) in targets.items():
    # Get current detection
    cube = get_cube(detections, color)
    
    # If not found or incomplete, re-observe
    if cube is None or not cube.complete:
        try:
            robot.move_to(observe_pose, speed_scale=0.7)
        except (OutOfReach, Singularity, Collision):
            pass  # Already near, continue
        detections = robot.detect()
        cube = get_cube(detections, color) or cube  # Use best available
    
    if cube is None:
        continue  # Skip if still not found
    
    # Current and target poses
    current_z = cube.position[2]
    pick = Pose(cube.position[0], cube.position[1], current_z, cube.yaw_rad)
    place_z = 0.0225  # Cube centre on table
    place = Pose(tx, ty, place_z, cube.yaw_rad)
    
    # Pick
    approach_height = 0.10
    lift_height = 0.10
    robot.move_to(pick.above(approach_height), speed_scale=0.8)
    robot.move_to(pick, speed_scale=0.5)
    robot.grasp()
    robot.move_to(pick.above(lift_height), speed_scale=0.5)
    
    # Place
    robot.move_to(place.above(lift_height), speed_scale=0.8)
    robot.move_to(place.above(0.005), speed_scale=0.5)
    robot.release()
    robot.move_to(place.above(lift_height), speed_scale=0.8)
    
    # Update detections after move
    detections = robot.detect()

# Return to ready pose to finish cleanly
robot.move_to(Pose(-0.50, 0.00, 0.25), speed_scale=0.8)
