def get_detections(target="any"):
    return robot.detect(target)

def find_cube(dets, color):
    for d in dets:
        if d.color == color:
            return d
    return None

def move_with_retry(pose, speed_scale=1.0):
    try:
        robot.move_to(pose, speed_scale)
    except (OutOfReach, Singularity, Collision):
        return False
    return True

# Target positions for each color
targets = {
    "blue": Pose(-0.628, -0.133, 0.0225),
    "red": Pose(-0.601, 0.162, 0.0225),
    "green": Pose(-0.477, 0.162, 0.0225)
}

# Observation pose to avoid arm shadow
observe_pose = Pose(-0.30, 0.0, 0.15)

# First detection
detections = get_detections()
colors_needed = ["blue", "red", "green"]
held = []

# Try to find and move each cube
for color in colors_needed:
    d = find_cube(detections, color)
    if d is None or not d.complete:
        # Move to observation pose only if needed
        move_with_retry(observe_pose)
        detections = get_detections()
        d = find_cube(detections, color)
        if d is None:
            continue  # Skip if still not found
    
    # Create pick and place poses
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = targets[color]
    
    # Lift height: just enough to clear other cubes (10 cm above table is safe)
    lift_z = 0.1225
    
    # Pick sequence
    if not move_with_retry(pick.above(lift_z)):
        continue
    if not move_with_retry(pick.above(0.02), 0.5):  # Slow descent
        continue
    try:
        robot.grasp()
        held.append(color)
        # Lift after grasp
        if not move_with_retry(pick.above(lift_z), 0.5):
            continue
        
        # Place sequence
        if not move_with_retry(place.above(lift_z)):
            continue
        if not move_with_retry(place.above(0.005), 0.5):  # Slow release
            continue
        robot.release()
        # Lift after release
        move_with_retry(place.above(lift_z))
    except NoObjectGrasped:
        pass

# Return to ready pose to finish cleanly
robot.move_to(Pose(-0.50, 0.00, 0.25))
