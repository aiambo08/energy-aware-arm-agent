def get_detections():
    dets = robot.detect()
    colors = {}
    for d in dets:
        if d.color not in colors:
            colors[d.color] = []
        colors[d.color].append(d)
    return colors

def sort_cubes():
    target_positions = {
        "green": (-0.578, 0.070),
        "yellow": (-0.540, -0.042),
        "red": (-0.626, 0.197)
    }
    
    # Initial detection from ready pose
    colors = get_detections()
    
    # Move to observation pose only if any target cube is missing
    needed_colors = set(target_positions.keys())
    if not needed_colors.issubset(colors.keys()):
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        colors = get_detections()
    
    # For each color, pick and place at target
    for color, (tx, ty) in target_positions.items():
        if color not in colors or not colors[color]:
            continue
            
        # Use first detection (assume only one per color)
        d = colors[color][0]
        pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
        place_z = 0.0225  # Cube center at rest on table
        place_pose = Pose(tx, ty, place_z, d.yaw_rad)
        
        # Pick
        approach_height = 0.10
        robot.move_to(pick_pose.above(approach_height))
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        
        # Lift
        robot.move_to(pick_pose.above(approach_height), 0.5)
        
        # Place
        robot.move_to(place_pose.above(approach_height))
        robot.move_to(place_pose.above(0.005), 0.5)
        robot.release()
        
        # Return to safe height
        robot.move_to(place_pose.above(approach_height))

sort_cubes()
