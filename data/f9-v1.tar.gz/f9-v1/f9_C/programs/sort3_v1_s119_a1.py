targets = {
    "yellow": Pose(-0.388, -0.049, 0.0225),
    "red": Pose(-0.530, -0.147, 0.0225),
    "blue": Pose(-0.457, 0.038, 0.0225)
}

def get_detections():
    try:
        return robot.detect("any")
    except:
        return []

def find_cube(dets, color):
    return next((d for d in dets if d.color == color), None)

def approach_height(detection):
    return detection.position[2] + 0.10

def lift_height(detection):
    return detection.position[2] + 0.10

detections = get_detections()
observed = {d.color: d for d in detections}

# Move to observation pose only if needed
if not all(color in observed for color in targets.keys()):
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = get_detections()
    observed.update({d.color: d for d in detections})

for color, target_pose in targets.items():
    d = observed.get(color)
    if d is None:
        continue
        
    pick_pose = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    approach_pose = pick_pose.above(0.10)
    lift_pose = pick_pose.above(0.10)
    place_pose = target_pose.with_yaw(pick_pose.yaw)

    try:
        robot.move_to(approach_pose)
        robot.move_to(pick_pose, 0.5)
        robot.grasp()
        robot.move_to(lift_pose, 0.5)
        robot.move_to(place_pose.above(0.10))
        robot.move_to(place_pose.above(0.005), 0.5)
        robot.release()
        robot.move_to(place_pose.above(0.10))
    except (OutOfReach, Singularity, Collision, Timeout, NoObjectGrasped):
        continue
