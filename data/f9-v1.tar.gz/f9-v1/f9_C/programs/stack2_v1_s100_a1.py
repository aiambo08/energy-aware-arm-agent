def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red = find_cube(detections, "red")
green = find_cube(detections, "green")

# If either cube is missing or red is incomplete, move to observation pose
if red is None or green is None or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    green = find_cube(detections, "green") or green

# Use green's position as base, compute target place for red on top
place_z = green.position[2] + 0.045  # One cube height above green's center
place_pose = Pose(green.position[0], green.position[1], place_z, red.yaw_rad if red else 0.0)

# Pick up red cube
if red:
    pick_pose = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
    approach_height = 0.10
    # Clear nearby cubes: reduce lift if possible, but ensure clearance
    if red.depth_m < 0.15:
        approach_height = max(0.06, red.depth_m + 0.02)
    
    robot.move_to(pick_pose.above(approach_height))
    robot.move_to(pick_pose, 0.5)
    robot.grasp()
    robot.move_to(pick_pose.above(approach_height), 0.5)

    # Place red on green
    robot.move_to(place_pose.above(approach_height))
    robot.move_to(place_pose.above(0.005), 0.5)
    robot.release()
    robot.move_to(place_pose.above(approach_height))

# Return to ready pose to finish
robot.move_to(Pose(-0.50, 0.0, 0.25))
