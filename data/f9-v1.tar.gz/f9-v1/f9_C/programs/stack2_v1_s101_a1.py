def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
red = find_cube(detections, "red")
blue = find_cube(detections, "blue")

# If red or blue not seen clearly, move to observation pose
if red is None or blue is None or not red.complete or not blue.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    blue = find_cube(detections, "blue") or blue

# Use the best available detection
if red is None:
    raise PrimitiveError("No red cube detected")
if blue is None:
    raise PrimitiveError("No blue cube detected")

# Define pick and place poses
pick_red = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
place_on_blue = Pose(blue.position[0], blue.position[1], blue.position[2] + 0.045, red.yaw_rad)

# Pick up red cube
approach_height = 0.10
clearance = 0.015
robot.move_to(pick_red.above(approach_height))
robot.move_to(pick_red.above(clearance), 0.5)
robot.move_to(pick_red, 0.5)
robot.grasp()
robot.move_to(pick_red.above(approach_height), 0.5)

# Place on blue cube
robot.move_to(place_on_blue.above(approach_height))
robot.move_to(place_on_blue.above(0.005), 0.5)
robot.release()
robot.move_to(place_on_blue.above(approach_height))
