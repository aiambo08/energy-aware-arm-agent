def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
blue = find_cube(detections, "blue")
red = find_cube(detections, "red")

# If red or blue is missing or incomplete, move to observation pose
if blue is None or red is None or not blue.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    red = find_cube(detections, "red") or red

# Ensure we have both cubes
if blue is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")
if red is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")

# Pick pose for blue cube
pick_blue = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Place pose: on top of red cube, centred, with same yaw as blue (arbitrary for cube)
place_z = red.position[2] + 0.045  # red centre + one cube height
place_blue = Pose(red.position[0], red.position[1], place_z, blue.yaw_rad)

# Pick up blue cube
approach_height = 0.10
robot.move_to(pick_blue.above(approach_height))
robot.move_to(pick_blue, 0.5)
robot.grasp()
robot.move_to(pick_blue.above(approach_height), 0.5)

# Move to above red cube
robot.move_to(place_blue.above(approach_height))
robot.move_to(place_blue.above(0.005), 0.5)
robot.release()
robot.move_to(place_blue.above(approach_height))
