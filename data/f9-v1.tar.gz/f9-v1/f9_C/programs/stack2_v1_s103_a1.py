def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red = find_cube(detections, "red")
green = find_cube(detections, "green")

# If either cube is missing or red is incomplete, move to observation pose
if red is None or green is None or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    green = find_cube(detections, "green") or green

# Use green's position as base, red's for grasping
if red is None or green is None:
    raise PrimitiveError("Missing red or green cube")

# Target grasp pose for red cube
grasp_red = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
# Target place pose: on top of green, centred at green's top center + half cube height
place_z = green.top_center[2] + 0.0225  # centre of red when resting on green
place_red = Pose(green.top_center[0], green.top_center[1], place_z, red.yaw_rad)

# Pick up red cube
robot.move_to(grasp_red.above(0.10))
robot.move_to(grasp_red, 0.5)
robot.grasp()
robot.move_to(grasp_red.above(0.10), 0.5)

# Place on green
robot.move_to(place_red.above(0.10))
robot.move_to(place_red.above(0.005), 0.5)
robot.release()
robot.move_to(place_red.above(0.10))
