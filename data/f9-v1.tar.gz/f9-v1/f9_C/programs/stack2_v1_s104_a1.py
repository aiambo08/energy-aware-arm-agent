def find_cube(detections, color):
    return next((d for d in detections if d.color == color), None)

# Initial detection
detections = robot.detect()
blue = find_cube(detections, "blue")
red = find_cube(detections, "red")

# If red or blue is missing or incomplete, move to observation pose
if blue is None or red is None or not blue.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    red = find_cube(detections, "red") or red

# Ensure we have both cubes
if blue is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")
if red is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")

# Grasp pose for blue cube (top center, aligned with its yaw)
pick_blue = Pose(blue.top_center[0], blue.top_center[1], blue.top_center[2], blue.yaw_rad)
# Place pose: on top of red cube, centered, with same yaw as blue (or any valid orientation)
place_z = red.position[2] + 0.045  # red center + one cube height
place_blue = Pose(red.position[0], red.position[1], place_z, blue.yaw_rad)

# Pick up blue cube
robot.move_to(pick_blue.above(0.10))
robot.move_to(pick_blue, 0.5)
robot.grasp()
robot.move_to(pick_blue.above(0.10), 0.5)

# Place on red cube
robot.move_to(place_blue.above(0.10))
robot.move_to(place_blue.above(0.005), 0.5)
robot.release()
robot.move_to(place_blue.above(0.10))
