def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
blue = find_cube(detections, "blue")
yellow = find_cube(detections, "yellow")

# If either cube is not detected or has incomplete top, move to observation pose
if blue is None or yellow is None or not blue.complete or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    yellow = find_cube(detections, "yellow") or yellow

# Ensure we have both cubes
if blue is None:
    raise PrimitiveError("NoObjectGrasped", "Blue cube not found")
if yellow is None:
    raise PrimitiveError("NoObjectGrasped", "Yellow cube not found")

# Pick pose for blue cube
pick_blue = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
# Place pose: on top of yellow, centred, with same yaw as blue for alignment
place_z = yellow.position[2] + 0.045  # One cube height higher
place_blue = Pose(yellow.position[0], yellow.position[1], place_z, blue.yaw_rad)

# Pick up blue cube
approach_height = max(0.10, blue.position[2] + 0.10)  # At least 10 cm above
robot.move_to(pick_blue.above(approach_height))
robot.move_to(pick_blue, 0.5)
robot.grasp()
# Lift after grasp
robot.move_to(pick_blue.above(0.10), 0.5)

# Move above yellow cube
robot.move_to(place_blue.above(0.10))
# Descend slowly for precision
robot.move_to(place_blue.above(0.005), 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_blue.above(0.10))
