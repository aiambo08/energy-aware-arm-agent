def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
green = find_cube(detections, "green")
blue = find_cube(detections, "blue")

# If either cube is missing or top face not fully visible, move to observation pose
if green is None or blue is None or not green.complete or not blue.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    blue = find_cube(detections, "blue") or blue

# Use the blue cube's position as base; target z for green on top
place_z = blue.position[2] + 0.045  # One cube height higher
place_pose = Pose(blue.position[0], blue.position[1], place_z, blue.yaw_rad)

# Pick green cube
pick_pose = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
approach_height = max(0.10, blue.position[2] + 0.10)  # Clear nearby cubes

robot.move_to(pick_pose.above(approach_height))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(approach_height), 0.5)

# Place on blue
robot.move_to(place_pose.above(approach_height))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(approach_height))
