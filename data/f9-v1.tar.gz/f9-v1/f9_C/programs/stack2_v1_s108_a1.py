def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
green = find_cube(detections, "green")
yellow = find_cube(detections, "yellow")

# If either cube is not fully visible, move to observation pose
if green is None or yellow is None or not green.complete or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    yellow = find_cube(detections, "yellow") or yellow

# Use the yellow cube's position as base; target z for placing green on top
place_z = yellow.position[2] + 0.045  # One cube height higher

# Prepare pick and place poses for green cube
pick = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
place = Pose(yellow.position[0], yellow.position[1], place_z, green.yaw_rad)

# Pick up the green cube
robot.move_to(pick.above(0.10))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(0.10), 0.5)

# Place on top of yellow cube
robot.move_to(place.above(0.10))
robot.move_to(place.above(0.005), 0.5)
robot.release()

# Lift slightly to clear after release
robot.move_to(place.above(0.10))
