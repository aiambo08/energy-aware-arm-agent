def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red = find_cube(detections, "red")
blue = find_cube(detections, "blue")

# If either cube is missing or red is incomplete, move to observation pose
if red is None or blue is None or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    blue = find_cube(detections, "blue") or blue

# Use blue's position as base, red's for pickup
pick = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
# Place red on top of blue, centred at blue's top center + half cube height
place_z = blue.top_center[2] + 0.0225  # top_center is top face, add half height to get center
place = Pose(blue.top_center[0], blue.top_center[1], place_z, red.yaw_rad)

# Pick up red cube
approach_height = 0.10
robot.move_to(pick.above(approach_height))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(approach_height), 0.5)

# Place on blue
robot.move_to(place.above(approach_height))
robot.move_to(place.above(0.005), 0.5)
robot.release()
robot.move_to(place.above(approach_height))
