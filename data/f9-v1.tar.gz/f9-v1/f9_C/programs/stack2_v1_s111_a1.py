def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue = find_cube(detections, "blue")
green = find_cube(detections, "green")

# If either cube is missing or partially seen, move to observation pose
if blue is None or green is None or not blue.complete or not green.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

# Use green's position as base; target stack height is ~0.045 m above green's center
stack_z = green.position[2] + 0.045
place_pose = Pose(green.position[0], green.position[1], stack_z, green.yaw_rad)

# Pick blue cube
pick_pose = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
approach_pick = pick_pose.above(0.10)
lift_after_pick = approach_pick

# Move to pick
robot.move_to(approach_pick)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(lift_after_pick, 0.5)

# Move to place on green
robot.move_to(place_pose.above(0.10))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_pose.above(0.10))
