def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
dets = robot.detect()
green = find_cube(dets, "green")
red = find_cube(dets, "red")

# If either cube is missing or partially seen, move to observation pose
if green is None or red is None or not green.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect()
    green = find_cube(dets, "green") or green
    red = find_cube(dets, "red") or red

# Use the best available detection
assert green is not None and red is not None, "Missing green or red cube"

# Pick green cube
pick_green = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
# Place on top of red, centred at red's top center, z increased by half cube height (0.0225 m)
place_z = red.top_center[2] + 0.0225
place_green = Pose(red.top_center[0], red.top_center[1], place_z, green.yaw_rad)

# Pick up green
robot.move_to(pick_green.above(0.10))
robot.move_to(pick_green, 0.5)
robot.grasp()
robot.move_to(pick_green.above(0.10), 0.5)

# Place on red
robot.move_to(place_green.above(0.10))
robot.move_to(place_green.above(0.005), 0.5)
robot.release()
robot.move_to(place_green.above(0.10))
