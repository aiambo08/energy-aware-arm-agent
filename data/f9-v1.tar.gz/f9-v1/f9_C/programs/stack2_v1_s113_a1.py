def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
red = find_cube(detections, "red")
yellow = find_cube(detections, "yellow")

# If red or yellow not seen clearly, move to observation pose
if red is None or yellow is None or not red.complete or not yellow.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    yellow = find_cube(detections, "yellow") or yellow

# Use the yellow cube's position as base; target z for placing red on top
place_z = yellow.position[2] + 0.045  # One cube height higher
place_pose = Pose(yellow.position[0], yellow.position[1], place_z, yellow.yaw_rad)

# Pick up the red cube
pick_pose = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
approach_pick = pick_pose.above(0.10)
lift_after_pick = approach_pick

# Move to above red cube
robot.move_to(approach_pick)
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(lift_after_pick, 0.5)

# Move above yellow cube and place red on top
approach_place = place_pose.above(0.10)
robot.move_to(approach_place)
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(approach_place)
