def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# Initial detection
detections = robot.detect()
green = find_cube(detections, "green")
red = find_cube(detections, "red")

# If either cube is missing or partial, move to observation pose
if green is None or red is None or not green.complete or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    red = find_cube(detections, "red") or red

# Ensure we have both cubes
if green is None:
    raise PrimitiveError("NoObjectGrasped", "Green cube not found")
if red is None:
    raise PrimitiveError("NoObjectGrasped", "Red cube not found")

# Pick pose for green cube (grasp at its center, aligned with its yaw)
pick_green = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)
# Place pose: on top of red cube, centered, 0.045 m higher (cube height), same yaw as red
place_z = red.position[2] + 0.045
place_green = Pose(red.position[0], red.position[1], place_z, red.yaw_rad)

# Pick green cube
approach_height = 0.10
robot.move_to(pick_green.above(approach_height))
robot.move_to(pick_green, 0.5)
robot.grasp()
robot.move_to(pick_green.above(approach_height), 0.5)

# Place on red cube
robot.move_to(place_green.above(approach_height))
robot.move_to(place_green.above(0.005), 0.5)
robot.release()
robot.move_to(place_green.above(approach_height))
