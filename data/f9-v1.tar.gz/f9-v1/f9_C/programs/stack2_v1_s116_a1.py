def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
red = find_cube(detections, "red")
blue = find_cube(detections, "blue")

# If either cube is missing or red top not fully visible, move to observation pose
if red is None or blue is None or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    red = find_cube(detections, "red") or red
    blue = find_cube(detections, "blue") or blue

# Use the blue cube's position as base; target z is one cube height higher
target_z = blue.position[2] + 0.045

# Prepare pick and place poses for red cube
pick = Pose(red.position[0], red.position[1], red.position[2], red.yaw_rad)
place = Pose(blue.position[0], blue.position[1], target_z, red.yaw_rad)

# Pick up the red cube
robot.move_to(pick.above(0.10))
robot.move_to(pick, 0.5)
robot.grasp()
robot.move_to(pick.above(0.10), 0.5)

# Place on top of blue cube
robot.move_to(place.above(0.10))
robot.move_to(place.above(0.005), 0.5)
robot.release()

# Lift slightly to clear
robot.move_to(place.above(0.10))
