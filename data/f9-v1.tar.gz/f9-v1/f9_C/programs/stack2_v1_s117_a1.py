def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
detections = robot.detect()
blue = find_cube(detections, "blue")
green = find_cube(detections, "green")

# If either cube is missing or partially seen, move to observation pose
if blue is None or green is None or not blue.complete or not green.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    blue = find_cube(detections, "blue") or blue
    green = find_cube(detections, "green") or green

# Compute grasp poses
pick_blue = Pose(blue.position[0], blue.position[1], blue.position[2], blue.yaw_rad)
place_on_green = Pose(green.position[0], green.position[1], green.position[2] + 0.045, blue.yaw_rad)

# Pick up blue cube
robot.move_to(pick_blue.above(0.10))
robot.move_to(pick_blue, 0.5)
robot.grasp()
robot.move_to(pick_blue.above(0.10), 0.5)

# Place on green cube
robot.move_to(place_on_green.above(0.10))
robot.move_to(place_on_green.above(0.005), 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_on_green.above(0.10))
