def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First, detect all cubes
detections = robot.detect()

# Get the green and red cubes
green = find_cube(detections, "green")
red = find_cube(detections, "red")

# If green or red is missing or partial, move to observation pose to improve detection
if green is None or not green.complete or red is None or not red.complete:
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    detections = robot.detect()
    green = find_cube(detections, "green") or green
    red = find_cube(detections, "red") or red

# If still missing, fail gracefully (but task assumes cubes exist)
if green is None or red is None:
    robot.reset()
    raise PrimitiveError("Missing green or red cube")

# Target grasp pose for green cube (at its center, with correct yaw)
grasp_green = Pose(green.position[0], green.position[1], green.position[2], green.yaw_rad)

# Target place pose: on top of red cube, centered, with same yaw as green (or aligned)
# Red cube center is at red.position; top center is at z = red.position[2] + 0.045
place_z = red.position[2] + 0.045
place_green = Pose(red.position[0], red.position[1], place_z, grasp_green.yaw).above(0.005)

# Pick up the green cube
approach_height = 0.10
robot.move_to(grasp_green.above(approach_height))
robot.move_to(grasp_green, 0.5)
robot.grasp()
robot.move_to(grasp_green.above(approach_height), 0.5)

# Move above red cube and place gently
robot.move_to(place_green.above(approach_height))
robot.move_to(place_green, 0.5)
robot.release()

# Lift slightly after release
robot.move_to(place_green.above(approach_height))
