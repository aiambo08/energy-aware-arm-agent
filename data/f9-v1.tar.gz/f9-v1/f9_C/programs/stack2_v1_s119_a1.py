def find_cube(detections, color):
    for d in detections:
        if d.color == color:
            return d
    return None

# First detection from ready pose
dets = robot.detect()
yellow = find_cube(dets, "yellow")
red = find_cube(dets, "red")

# If either cube is missing or partial, move to observation pose
if (yellow is None or not yellow.complete or red is None or not red.complete):
    robot.move_to(Pose(-0.30, 0.0, 0.15))
    dets = robot.detect()
    yellow = find_cube(dets, "yellow") or yellow
    red = find_cube(dets, "red") or red

# Use red cube's position as base; yellow will be placed on top
place_z = red.position[2] + 0.045  # One cube height above red's center
place_pose = Pose(red.position[0], red.position[1], place_z, red.yaw_rad)

# Pick yellow cube
pick_pose = Pose(yellow.position[0], yellow.position[1], yellow.position[2], yellow.yaw_rad)
approach_height = max(0.10, red.position[2] + 0.10)  # Clear the red cube when moving

# Move to pick
robot.move_to(pick_pose.above(approach_height))
robot.move_to(pick_pose, 0.5)
robot.grasp()
robot.move_to(pick_pose.above(approach_height), 0.5)

# Move to place on red
robot.move_to(place_pose.above(approach_height))
robot.move_to(place_pose.above(0.005), 0.5)
robot.release()
robot.move_to(place_pose.above(approach_height))
