robot.execute_skill("place_cube_over_wall", color="green", x=-0.640, y=-0.073)
