try:
    robot.execute_skill("place_cube_over_wall", color="red", x=-0.548, y=0.109)
except SkillPreconditionFailed:
    dets = robot.detect("red")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("red")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="red", x=-0.548, y=0.109)
except (SkillPostconditionFailed, SkillFailed):
    pass
