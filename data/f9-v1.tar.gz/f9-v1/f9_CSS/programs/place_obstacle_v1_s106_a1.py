robot.execute_skill("place_cube_over_wall", color="red", x=-0.525, y=0.181)
