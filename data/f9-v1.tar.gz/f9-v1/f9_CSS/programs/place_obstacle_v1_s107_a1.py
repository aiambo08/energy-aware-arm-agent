robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.358, y=0.195)
