robot.execute_skill("place_cube_over_wall", color="green", x=-0.394, y=0.076)
