try:
    robot.execute_skill("place_cube_over_wall", color="blue", x=-0.529, y=-0.172)
except SkillPreconditionFailed:
    dets = robot.detect("blue")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("blue")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="blue", x=-0.529, y=-0.172)
