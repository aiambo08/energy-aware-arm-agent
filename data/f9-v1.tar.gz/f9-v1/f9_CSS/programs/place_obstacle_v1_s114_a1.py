try:
    robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.374, y=-0.081)
except SkillPreconditionFailed:
    dets = robot.detect("yellow")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("yellow")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.374, y=-0.081)
except (SkillPostconditionFailed, SkillFailed):
    dets = robot.detect("yellow")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("yellow")
    if dets:
        d = dets[0]
        pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
        place = Pose(-0.374, -0.081, d.position[2])
        robot.move_to(pick.above(0.10))
        robot.move_to(pick, 0.5)
        robot.grasp()
        robot.move_to(pick.above(0.10), 0.5)
        robot.move_to(place.above(0.10))
        robot.move_to(place.above(0.005), 0.5)
        robot.release()
        robot.move_to(place.above(0.10))
