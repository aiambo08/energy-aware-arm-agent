try:
    robot.execute_skill("place_cube_over_wall", color="green", x=-0.379, y=0.198)
except SkillPreconditionFailed:
    dets = robot.detect("green")
    if not dets:
        robot.move_to(Pose(-0.30, 0.0, 0.15))
        dets = robot.detect("green")
    if dets:
        robot.execute_skill("place_cube_over_wall", color="green", x=-0.379, y=0.198)
except (SkillPostconditionFailed, SkillFailed):
    d = None
    dets = robot.detect("green")
    if dets:
        d = dets[0]
    else:
        poses = [Pose(-0.30, 0.0, 0.15), Pose(-0.30, 0.25, 0.15), Pose(-0.30, -0.25, 0.15)]
        for p in poses:
            robot.move_to(p)
            dets = robot.detect("green")
            if dets:
                d = dets[0]
                break
    if d is None:
        raise PrimitiveError("No green cube detected")
    pick = Pose(d.position[0], d.position[1], d.position[2], d.yaw_rad)
    place = Pose(-0.379, 0.198, pick.z)
    robot.move_to(pick.above(0.10))
    robot.move_to(pick, 0.5)
    robot.grasp()
    robot.move_to(pick.above(0.10), 0.5)
    robot.move_to(place.above(0.10))
    robot.move_to(place.above(0.005), 0.5)
    robot.release()
    robot.move_to(place.above(0.10))
