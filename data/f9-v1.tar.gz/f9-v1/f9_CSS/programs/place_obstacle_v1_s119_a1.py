robot.execute_skill("place_cube_over_wall", color="yellow", x=-0.589, y=-0.179)
