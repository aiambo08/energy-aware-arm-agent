robot.execute_skill("sort_cubes", 
                   color_1="blue", x_1=-0.541, y_1=0.167,
                   color_2="red", x_2=-0.352, y_2=-0.108,
                   color_3="green", x_3=-0.628, y_3=0.019)
