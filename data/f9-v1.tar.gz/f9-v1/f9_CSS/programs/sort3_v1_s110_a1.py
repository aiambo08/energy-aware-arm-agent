robot.execute_skill("sort_cubes", 
                   color_1="green", x_1=-0.536, y_1=-0.145,
                   color_2="blue", x_2=-0.354, y_2=-0.025,
                   color_3="red", x_3=-0.370, y_3=0.133)
