robot.execute_skill("sort_cubes", 
                   color_1="green", x_1=-0.475, y_1=0.018,
                   color_2="yellow", x_2=-0.388, y_2=0.126,
                   color_3="blue", x_3=-0.641, y_3=0.102)
