robot.execute_skill("sort_cubes", 
                   color_1="red", x_1=-0.537, y_1=0.086,
                   color_2="yellow", x_2=-0.364, y_2=-0.166,
                   color_3="blue", x_3=-0.390, y_3=-0.021)
