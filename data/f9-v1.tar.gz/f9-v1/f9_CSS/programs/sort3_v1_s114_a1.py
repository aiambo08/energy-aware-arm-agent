robot.execute_skill("sort_cubes", 
                   color_1="blue", x_1=-0.616, y_1=-0.147,
                   color_2="yellow", x_2=-0.496, y_2=-0.102,
                   color_3="red", x_3=-0.362, y_3=0.176)
