robot.execute_skill("sort_cubes", 
    color_1="red", x_1=-0.487, y_1=-0.154,
    color_2="green", x_2=-0.565, y_2=0.185,
    color_3="blue", x_3=-0.617, y_3=0.077)
