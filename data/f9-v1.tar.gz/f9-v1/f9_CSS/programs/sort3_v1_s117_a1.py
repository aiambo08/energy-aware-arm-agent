robot.execute_skill("sort_cubes", 
    color_1="blue", x_1=-0.628, y_1=-0.133,
    color_2="red", x_2=-0.601, y_2=0.162,
    color_3="green", x_3=-0.477, y_3=0.162)
