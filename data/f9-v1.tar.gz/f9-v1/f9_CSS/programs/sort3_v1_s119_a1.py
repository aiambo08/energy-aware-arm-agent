robot.execute_skill("sort_cubes", 
    color_1="yellow", x_1=-0.388, y_1=-0.049,
    color_2="red", x_2=-0.530, y_2=-0.147,
    color_3="blue", x_3=-0.457, y_3=0.038)
